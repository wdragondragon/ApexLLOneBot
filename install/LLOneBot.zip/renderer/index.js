const SettingList = (items, title, isCollapsible = false, direction = "column") => {
  return `<setting-section ${""}>
    <setting-panel>
        <setting-list ${direction ? `data-direction="${direction}"` : ""} ${isCollapsible ? "is-collapsible" : ""} ${""}>
            ${items.join("")}
        </setting-list>
    </setting-panel>
</setting-section>`;
};
const SettingItem = (title, subtitle, action, id, visible = true) => {
  return `<setting-item ${id ? `id="${id}"` : ""} ${!visible ? "is-hidden" : ""}>
    <div>
        <setting-text>${title}</setting-text>
        ${subtitle ? `<setting-text data-type="secondary">${subtitle}</setting-text>` : ""}
    </div>
    ${action ? `<div>${action}</div>` : ""}
</setting-item>`;
};
const SettingButton = (text, id, type = "secondary") => {
  return `<setting-button ${type ? `data-type="${type}"` : ""} ${id ? `id="${id}"` : ""}>${text}</setting-button>`;
};
const SettingSwitch = (configKey, isActive = false, extraData) => {
  return `<setting-switch 
    ${configKey ? `data-config-key="${configKey}"` : ""} 
    ${isActive ? "is-active" : ""} 
    ${extraData ? Object.keys(extraData).map((key) => `data-${key}="${extraData[key]}"`) : ""} 
    >
</setting-switch>`;
};
const SettingOption = (text, value, isSelected = false) => {
  return `<setting-option ${value ? `data-value="${value}"` : ""} ${isSelected ? "is-selected" : ""}>${text}</setting-option>`;
};
const SelectTemplate = document.createElement("template");
SelectTemplate.innerHTML = `<style>
    .hidden { display: none !important; }
</style>
<div part="parent">
        <div part="button">
            <input type="text" placeholder="请选择" part="current-text" />
            <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" part="button-arrow">
                <path d="M12 6.0001L8.00004 10L4 6" stroke="currentColor" stroke-linejoin="round"></path>
            </svg>
        </div>
    <ul class="hidden" part="option-list"><slot></slot></ul>
</div>`;
window.customElements.define(
  "ob-setting-select",
  class extends HTMLElement {
    _button;
    _text;
    _context;
    constructor() {
      super();
      this.attachShadow({ mode: "open" });
      this.shadowRoot.append(SelectTemplate.content.cloneNode(true));
      this._button = this.shadowRoot.querySelector('div[part="button"]');
      this._text = this.shadowRoot.querySelector('input[part="current-text"]');
      this._context = this.shadowRoot.querySelector('ul[part="option-list"]');
      const buttonClick = () => {
        const isHidden = this._context.classList.toggle("hidden");
        window[`${isHidden ? "remove" : "add"}EventListener`]("pointerdown", windowPointerDown);
      };
      const windowPointerDown = ({ target }) => {
        if (!this.contains(target)) buttonClick();
      };
      this._button.addEventListener("click", buttonClick);
      this._context.addEventListener("click", ({ target }) => {
        if (target.tagName !== "SETTING-OPTION") return;
        buttonClick();
        if (target.hasAttribute("is-selected")) return;
        this.querySelectorAll("setting-option[is-selected]").forEach((dom) => dom.toggleAttribute("is-selected"));
        target.toggleAttribute("is-selected");
        this._text.value = target.textContent;
        this.dispatchEvent(
          new CustomEvent("selected", {
            bubbles: true,
            composed: true,
            detail: {
              name: target.textContent,
              value: target.dataset.value
            }
          })
        );
      });
      this._text.value = this.querySelector("setting-option[is-selected]").textContent;
    }
  }
);
const SettingSelect = (items, configKey, configValue) => {
  return `<ob-setting-select ${`data-config-key="${configKey}"`}>
    ${items.map((e, i) => {
    return SettingOption(e.text, e.value, configValue ? configValue === e.value : i === 0);
  }).join("")}
</ob-setting-select>`;
};
const StyleRaw = "setting-item[is-hidden],\nsetting-item[is-hidden] + setting-divider {\n  display: none !important;\n}\n\n.config-host-list {\n  width: 100%;\n  padding-left: 16px;\n  box-sizing: border-box;\n}\n.config-host-list[is-hidden],\n.config-host-list[is-hidden] + setting-divider {\n  display: none !important;\n}\n\nsetting-item .q-input {\n  height: 24px;\n  width: 100px;\n  border-top-left-radius: 4px;\n  border-top-right-radius: 4px;\n  border-bottom-right-radius: 4px;\n  border-bottom-left-radius: 4px;\n  box-sizing: border-box;\n  position: relative;\n  background: var(--bg_bottom_light);\n  border: 1px solid var(--border_dark);\n}\n\nsetting-item .q-input .q-input__inner {\n  border-top-left-radius: 4px;\n  border-top-right-radius: 4px;\n  border-bottom-right-radius: 4px;\n  border-bottom-left-radius: 4px;\n  box-sizing: border-box;\n  color: var(--text_primary);\n  font-family: inherit;\n  font-size: 12px;\n  height: 24px;\n  line-height: 24px;\n  width: 100%;\n  border: 1px solid transparent;\n  padding: 0px 8px;\n}\n\nsetting-item .q-input input[type='number'].q-input__inner::-webkit-outer-spin-button,\nsetting-item .q-input input[type='number'].q-input__inner::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n\n.config-host-list setting-item.setting-host-list-item .q-input {\n  width: 260px;\n}\n\nsetting-item a {\n  color: var(--text-link);\n}\nsetting-item a:hover {\n  color: var(--hover-link);\n}\nsetting-item a:active,\nsetting-item a:visited {\n  color: var(--text-link);\n}\n\nob-setting-select {\n  width: 100px;\n}\n\nob-setting-select,\nob-setting-select::part(parent),\nob-setting-select::part(button) {\n  display: block;\n  position: relative;\n  height: 24px;\n  font-size: 12px;\n  line-height: 24px;\n  box-sizing: border-box;\n}\n\nob-setting-select::part(button) {\n  display: flex;\n  padding: 0px 8px;\n  background-color: transparent;\n  border-radius: 4px;\n  border: 1px solid var(--border_dark);\n  z-index: 5;\n  cursor: default;\n  align-items: center;\n  flex-direction: row;\n  flex-wrap: nowrap;\n}\n\nob-setting-select::part(current-text) {\n  display: block;\n  margin-right: 8px;\n  padding: 0px;\n  background: none;\n  background-color: transparent;\n  font-size: 12px;\n  color: var(--text_primary);\n  text-overflow: ellipsis;\n  border-radius: 0px;\n  border: none;\n  outline: none;\n  overflow: hidden;\n  appearance: none;\n  box-sizing: border-box;\n  cursor: default;\n  flex: 1;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  -o-user-select: none;\n  user-select: none;\n  -webkit-pointer-events: none;\n  -moz-pointer-events: none;\n  -ms-pointer-events: none;\n  -o-pointer-events: none;\n  pointer-events: none;\n}\n\nob-setting-select::part(button-arrow) {\n  position: relative;\n  display: block;\n  width: 16px;\n  height: 16px;\n  color: var(--icon_primary);\n}\n\nob-setting-select::part(option-list) {\n  display: flex;\n  position: absolute;\n  top: 100%;\n  padding: 4px;\n  margin: 5px 0px;\n  width: 100%;\n  max-height: var(--q-contextmenu-max-height);\n  background-color: var(--blur_middle_standard);\n  background-clip: padding-box;\n  backdrop-filter: blur(8px);\n  font-size: 12px;\n  box-shadow: var(--shadow_bg_middle_secondary);\n  border: 1px solid var(--border_secondary);\n  border-radius: 4px;\n  box-sizing: border-box;\n  app-region: no-drag;\n  overflow-x: hidden;\n  overflow-y: auto;\n  list-style: none;\n  z-index: 999;\n  flex-direction: column;\n  align-items: stretch;\n  flex-wrap: nowrap;\n  justify-content: flex-start;\n  gap: 4px;\n}\n\n#llonebot-error {\n  display: none;\n}\n\n#llonebot-error setting-panel {\n  background: rgba(255, 0, 0, 0.5);\n  color: white;\n}\n\n#llonebot-error setting-panel pre {\n  margin: 0;\n  padding: 16px;\n  box-sizing: border-box;\n}\n\n#llonebot-error setting-panel pre code {\n  font-family: 'FiraCode Nerd Font', 'Fira Code', 'Cascadia Code', Consolas, 'Courier New', monospace;\n}\n\n#llonebot-error.show {\n  display: block;\n}\n";
const iconSvg = `
<?xml version="2.0" encoding="UTF-8" standalone="no"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="50px" y="10px" width="262px" height="150" viewBox="0 0 212 262" enable-background="new 0 0 212 262" xml:space="preserve">  
<image id="image0" width="212" height="210" x="0" y="-20" transform="rotate(180, 100, 100)"
    xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANQAAAEGCAYAAAAdX7uIAAAAIGNIUk0AAHomAACAhAAA+gAAAIDo
AAB1MAAA6mAAADqYAAAXcJy6UTwAAAAGYktHRAD/AP8A/6C9p5MAAAAJcEhZcwAADsMAAA7DAcdv
qGQAAIAASURBVHja7P1pvCTHdR+I/k9EZGYtd+sdDTR2gAQIkiAJ7uAqcRMpa5cl2bIlP3vs+Xns
5/GzZ+xne+xny34zli3LljfJkrWPbFl6lmRSlEiRFMUdJEAsBBprb+i9+/bdasslIs77kJlVWVlZ
GXW7+nY3SJxGoPJmZkRGRsaJs5+gew++EdcXcO1VyTM2c9lga68S0dUdjisNVP9+YsfH95sb1LXu
wHaBr/V8vtbPn7v/9QiFlxFqLhDXugMvw8vwzQQvOQpF13gFfakTqJfX0J2Fl0f3ZXgZriC8jFAv
w8twBeGqs3zNhsHGVgTmJlqtvWi3ltDpbkAnA/geEMNCSoKQAJsYSdwHWMPzJDxPkpdoeJ5CM/DQ
bPgIAo8CT0IJASJCK9hDYAEAlK4X2ZqRazPU+qgzTNl1MeLkKBm/f6wNAeErWGthjIFOLGttoLVl
YwysteibiNPrzDqx0FojSQyMsWBmsJfqKZkJzAxrRsfMQOKnzyeSANJ3AgsQ5WtfyvMyV/82Kar/
4JEhIQSklFBKQSkFz/MgpQQRYSGQ+XXKryulSEoJIQSsHfLcldyvNai97pnRlCv3HQB3YNhaC601
x3HMURQhiiKO4xhaawzYwhKYiMAAOPt0+eeKI42g4SGOY+zZswsXL17AQqOJsNtBq9GENjtLQ646
Qm1sDbC0uBvWEnrdSwi750EmgpIG7WYDC3ZAiwttuW/PLm/P7n0Ly8vtXbtWlm/Ytdy+qdVq3bxv
edeNSondDT9YarYarabvNQJfeVKSL4mDxUXRAOABQmbflcC5MlgAHGSfroh0mS6cBYESGhFuyu9D
fs4KAjPBWmuNsVYnVhtjEmsRMnNvo7/VtdZ2k8R0kyTpRVHSj6Okp7XuWIuNMxfPbhjNm0mS9OJY
99MSh0lsQmttdG5rK9Za6zAM7WAQ2V5vwP3egKMogtYaIGalFIIgQKvVona7Tc1mkxqNBimlxLKn
pFLKC4LAbzabzVar1W42m4tBECwqpZZ3N1tLUspFpVTL9/2W7/tN3/ebnue1hBCLuxcWV4hoUQjR
kFL6SilPSqmEEIqIRDZW5ZIDsZUonJtAKmKRI1C2sOQ/bAGYro4Ta22cJEkcx3EYRVE/DMNuHMfr
xpgLJy9ePBXH8eluv3fm0sb6mUuXLq1fvLTaX1tfTwaDAQ+ksEk/4ajbwaYFdD9Ca2U32Fhsbm2g
3VrZ0fl91RGKZAOthTbWL15A3L2IG/ct0n2vvKVxcP/ywZsO7n3n615x0w+0W43XLi4u7F5oNXzf
IyklkScFKSUQhgmEEFBCkCSRog3HaePMAAaFpwmMURgAQKOEJCPqg+FnBkZzQUwgFUCpdkQA1gNY
8ZDK3HxgX9oPJsCCYW1GhdLJoxbeDFjLMMzIqJwxbI0xzAzTTUgbY6IoSvqDfrQ1GAzWB4PoUhQl
68aYPgArpfSCIFhqNpv7ms3mnmazuRQEQVNKGextL/gAFOUkDhA0Mp6Rjg2ICEREQgiQEIDI8IQI
eqtH2fW0QACW0vchglNKcGjlx+pPUigseEvpQZCet9bmhZkZb3yll2Ef2yRJTG8wCLv93ma/3z8d
JfFzjx15/svnzp358tEXT5w+t3pu64WLqzrs9Nlv+IDydn5+X23DrpYBVto+ts4fw+0Hl4L3vfP+
7/v2d7/h/7O8IG/Zv2/FjzfXyPM8angKUhGsTtJiNcCMYGEl+xgA2ADWgk3KgsEyVONQCQGyuZSf
kxuFa0V2sIQ009oQhQmRz9mCccwmYXqJBAgym6gyKwQOo+y6HE1QyogpZLZsj5CZOdNrcvVEppKl
mTQVL47/AoDI1tAUw4eFsyKCpcmHFCY8rEQtuAyFeV/yNgttMzOifgQighBiWIhoWG+zO0DOsjIR
mMCGU4Sz1nKwsmjPnTsXnr904fRTzz3zf3/0jz7+b1+8dHaTWgFiGPhmZ/W0V51ChbFBn3o4sHdR
/sB3vecvf+Cdr/6/br5rf7N//kVqyB7Q8iGlTMUaISCVD8k+AAIkwdjC6klNAAQCQWUDnmwVuZAi
y5ZPrmxCVFKpaYg1muDSMnLZJiUCcqxd0WyM2rIYUitmAluGaDYLz0K2ootsYgmQGADgIbKm5KKC
kgITSJGeSq8PKU9OfbJfHYaF8RtN1pQaARgS+xH1yAswjptVYG39DbawIFXIUGju3j3xfjmVYmYs
79qVEX4LwxaaLUlmEDNJAF7McldjwbvtNYdeec8dd/0Dz/OWf/MPfvfvnVg/l1glRt9rh+CqI5SU
EuAEN9+4p/nWN977v+xZVk0M1qnb2YCgJcBfgTEWiU4pDzEDsBBIP3oiPQAMwQQiA2KChATAIAa8
xX72pCJlKiCJWRkd579jCghbOD+JdKwzqTsXJ1iMUZsk6meINmqbhpQI0DqfRBi2n86ntI7M9SMM
MGtwhnCcIVxeJydMOXLk7yvbjZTiGANjDEwSD5UozIygsTxsH5xP5rwAvudlfeIJpAIAqfza7+uy
E4psylUhEzOj0++P2iIaQ2hmhoQeIpdhThdeKaCUghAC/a0QvW4XTS+gxfaC/8BrX/ejX3rskX9+
dmtt1XgSSJw86Vxw1RGqFQRAvIVGQzSXl5q7e501Crw2Gs0F+K1dCCMALCBJQCqCEh6kUqmOQQhA
GGR0HjAp1webDTwIJt7MP8fwE44hhknSX5jsWgGBYADKEGaKlo8yLReXqFqONGwSgGzGrhBo2O8U
YUwSl6hDRuVypEiS0XNzyjKmJKn4ZIVJmQz0sH0pFJQqUSqNEZuXIVo+QZkZOpNHixO9CMbq2u/L
DpaP7DgClZ+lsnHJ2bohy5eDVYC1sDZdMLQxsGBwwjAw8NtNLApCrBN0VnvU8putdtDwiQU8zwMn
9VrQeeGqI5Q2MexgAGKr280g5oFk2V4i3yp0uhEWgyaYGGwsAIKwBogYzDHIMmKRIoRgACwhSWWy
ikRKAg5mX6saISA7AGyGZBYjdipTJJAu1TOFaxbwcxkEo+cMlVacIn/OwlkNGD1SUjBDNv0MASxY
56v/aCIqK8eF/7F5TVNklJFcopQcERwLMGz6rJxl07LA5gkokoAUI17OFpqkCnnMOkjQdpQSo0Es
nBEgpOwyGwtmA5uxfcwMkWRUWQpIQVAkYJhTpGLGWn+APctL8CBw4eI5KKU6gBhEUQRSBN/VvTnh
qiNU33hoBAvoRqb/6Dee+vq3vePVB9FbJ93rYHnPPoTdARqNFqB8hGEMKwh+OwBpDd3rQYrm6MOw
yL7fSM6RMhcCpiAUMrU5VVAwKlACmnLNFNi5cn0QUrIpRs+QJdnH2OHf6ZwtTGYWblM7199AU5yj
hq/rVUwpRkFJUKg/RqXyY0cHRf11M0bgaOwnfUoJiQuiLwFgPYBaaMFKiV4Ug4VES7VAUYLBVg8H
D92KiydfxMJCCwduuc1+7suf/fSZi6e7CSIopYB4Z+1QV91TYm/bR6/TxVPPvRg/9syZnzx3Ke4m
WADBBwYxGksrsDrBoLsJsIGSBIQaNragXEM11u2KV5iKTHWvX1JeVF6r+C0rPcp/j51zaBDH+jyt
XOfAor7MCcr3oBODJIpTBIs1+ltbIGYs79mNrbNn0W43ESw1+YVTR9Y+//hXf/rM6gUdKB9tsfNq
c7lv8carMMojoEEfC+0m+rHGqXNrZ4VqNe+8/fa37tq1S3KvCyQaNtEIWm2o5RUQE/qdLrQ2CNpL
gOVMIyVBJIfaNspYhZFHQZVxliZ/J7SAXDg/9KTAiN2qaH8MCRmotWFhsv7Ueyo/WeGZFWXY72nF
9Qw5Q31yFMccKNq5SgWcf8vqIhpNhP0ewjjBYquN5sIifBawcQzSBp4gBEstPttbG3zsi5/53z72
2T/65OrGJbvQasKzgGZ29m8euPoI1dvE7r37oKmBkxe27EYveqjdbNqDy8tvWVhe8owxIBCEkCm/
nhiwZpAKoPwGWFuMT4xxLR3lrNrw2jRkqtLiEVKEyCeVLExQiQnqVVKpj0PxucVjRj0y7TBCOBHO
gRDsQrj6ksqKdf2rf75QHqyxIBCkUOkSZjQYNlX4HdzDZ8+d6P3h1z7/zz/+lc/+3LMnj0XSV1jy
G9DdEKnnE+9YueoItbvhY70zQF8LLOw+gCS2ybNPH/7yoLPx/N133PW+xd17AhI+hb0e+htbEIbh
LyxB+W3EUZLJzyXKlB9TiUJxeVKXJ1Z2X1FjRwLjEy+3XaSr53C+lZEp/5tQUb/wzOF8oWqEdk34
mSZ0HShH3XkpkBuh6yiQC+GSKEbQbMEPGhj0++hsbYEFw283INuBvXDuxIWPfuYP/9eP/skf/cKx
i2cGWjECqSCMBRkLI3fWsHvVEQrQGGiGZYWg0YRONM6dPW0urq09c6kz+GMt1Bu8xsLePftukI1m
C2QtiNNJzVAQVLQTlWWlHKGoAplQmqyFCc80ft8YhZKYPtHyfhQQgyxqZaQxhCv2vXBPLcyLEI76
M1GwnaRwIjMpVBe2BClSTaZSEu29y/AWW3xy7VzyyDPf+NJHP/OxH/v45z79qedOHI1lw4Pv+Uii
CNYyPC9IbVdzv9/0ctURqjOIsbi8C0pKhFsbEDZBo9VCJ0ns4ROnT584de63N7rh2cVW6427262m
EoJMomEsw1MBiDhz6ylSJjmUq0Bcg0xFKLNiFdSsEgHnlJEmEK7cP9dHcyDd3DLU/BSo7npuf5tW
XCKOkgrWpM6Rwlc80JF58vhzz3/s85/5ax/97Cd/4uHnvn7izOoFK6RAMwjAcQxjGeRJJBKZp8vO
wdWXoRotSEHgOIQHRrvRgCGgZxmJauLchQuDI889/8jJYy/8lsexd3Df7lsbiysNSURxYkgOPUdK
SDCT4qH4sfNr5UlWNcEL56isPt6ujITJ+lWawangolCuNlwINS/LN+d1zpRL0/4ZgHyfqdFINtZX
T37q83/8L3/lv//m//MzD33+66c3V6MeD9BoNbHcbsNGCaL+AH6jCdlqYCPsobXDrkdX3Tm2ZKmc
vCoJZBiSCcvNlrzr0IEb3vT6e374wbfe/5fvufuW22Sy6XmCCGEHMCHQaABWINaADNrQvRjBygpg
DOJuF1LK1JGSGSSl245EZkYKV2bnZtTUscu51GF6dGapcZgWXc+fiQLOUd9rIBkMht4PWmv4vg8h
BDqdDhrtXZAMCClTm52OgYUGoAR3Ni9xe7/qP/fC8099/qEv/6eHHvv6R184deLSRr9rNRgsCN7O
ehY54bpDKKEIVjM4MSBtsBAo3LBvSd5yy/7l/XuX7//T73/vP7px/563LLX8ADYmCACJgbaAaiyA
TRqeEMdxikytFpAkSKIIXqORut7UagG59HeZrbOop0DXGKFc9eelYE6Eqkdoy0Acx2g0m+liGEUA
EZA5DdswhAljSBCIDRKrWTSU7SXR5ukL5z7zsc/89393/uLFx46fPtk5d/GC3YoGYEmAkiAlIfW1
xajrDqGUAFKfOIbWGiaOIcgg8CX8QGAvy+CD73vPm973rgf/1l233vBtjXZjAXEoTGwgGwHQ9IB+
H71eD41GA3JhAdzvIwxDNBcXgaTEsk2ovg2mI9PY0FXLQi6wLuPinBSGXc4vLoR01Z+TQvkBTBhC
+inidzc3kSQJGo1GGue2FCAehPA8j6Uv9drW2tlnjj3/259/6Mv/+XNf/uILm/FmEscxD6IodUVS
EtJTYJH6c17rvILXHUKR0VBKQXo+wARjGJpTfzQAoDBGy/fQ8KDuvuXGve9/zzve84b7X/W/LzQb
r7Ym8Q4uNSA9D5w5fUqlEIUhjDFoLS4CpiDjVNqR7PjfY+xcYTJerpaOHQg1N0vmQtidpUAuCqpt
5jUu5TAsw19aAjwFs7GJs70z1sBsJUZ/7fBzz/ziJz77R594/OmnNns6tCwJ8Gjk+U5ZvJRNF1+t
dRrNcA3hukMokXtCZD5w2jIsExgKRIROHGLPrmVYk6CzfhE+GXHT/l3eA6+5767Xv/a+f3xPO/ie
e++9V7b37AHCEFrr4Qfw/NwxFVPsSMAwEeQ01fdMWrq613dNyHkRwoWwc1KYOVnaMErg+z6ICIPB
AJ7nwdu3DLvWxcMPP7x1xpz+p1/+yld+47Gnn1hd73Vio8CiqWDB2OhsImhkvpyWISmzXjFgrU29
aOSMnMIOwXWHUB5JWGtgYWCthiUBggLBA0kFsRig3++j2+thod3Gvl2L0IMtdC6eI7J68Sd+9Ie+
9OCDD9530513AnGcylQqdflnawuhANPsSNrha4fCtQpKN/cKPy9CzMsSuhBmPhnMWAEZpA7Kg04H
zIxms4nnn3/efupTn/oHv/rZX/83vTgcNJfbHCy2sd7dQHfQRbvdxmK7hV43HIbGg9PFV4KGYR68
w65FLrgGht16EOQDYAgClGJ4ktBQCoFU8EmAoy7IGDSEh5bfgE0Mom4PNx44QO96+4Mr73jVK//u
wYMHmw0/SAMUhUy9HyynUaxz+9qV7DnbQibMZNish1ko4E6qvefz9bOWYbWGIIIXBPAaDVArwGKj
SUtLS60Nr/9bfR2HlzpbHELDEkEpBV8I2FgjkB48IeEJCSnSuLlRkOW1h+sOoWAVAAYJDSUsBBvA
MHScwMYJFkjDYwZxql6PewP4JOidb3zj0p/70z/82w+8+pX3NJaWieMEURRDCAmj0zRe0g8AW5KR
LtuOVLIfzexJPaeMNLevn9sOtJMIKdoL0JlMK4gQDQYwYYSg2cS+AwcOBTctPbDe3fzYmYsXwkEc
gwjwhYIPAdIWySACW5v7xWSxXYABjy2V1wp2AKHcu2fUBScEgYROYujEQsgGIALEBjAgCN/D7oUF
HD9/HmKxCbmokEQb9N3vfmDX3/nR7//EbfuX3w4TEpIERAylFCgTXKXwsuC4/El5PgiRUQ1V6oka
3ceF4+LvWD2J+jfLynBOFlfz/BkztlE72V2eDPXP4Dw+a0ohVx8dCGk1Q0gFIdNxk8qDlF4aZGlB
t7Vvu/3Nd9z3votrFz56+PjTvcZyA9rE2Dy/joPL+xFKg8SaVFElCJZtaiIRAu1mK021dg3hqlMo
1/oZZklEPM+D53lD3jg30K6uX8KBmw5BJwlMt0sfec+79vz4D37fH998w/7X8+Yqkd/KWprmKTGN
AlXZocruQIX7Ko2/NNsSyTTlGcXfaTCLYXcOCuNgncjxBV0I6Xp+vNGjhb27Dh687cYPdLqbv/vM
s0/3fE9h3759OHP+HFoLLUgp4XneMFEnEcEYgyiKIIRrhu0sXHcIxcwIggBKKWitEcfxMO+B1hrc
bCAOQywpjz749rfv+/Hv+97P3nvX7ffB9IkUA5RlSMqfVpVTL/+tDN+YZrh1qcxp4rbqF6SKumWX
qLr6OyyDOSgcOSiQSyXAjudb8iGUon379u2/af/+d0f9/sfOnT/X2ww70AGBsiQr+ZzIF18A14Xa
/Or78jkWT6kklKfAYIRRhEQnEDJllYw1UEtN9NbX8R1vf8euv/njP/bF2/buuidcv0jKY6DlA7rs
WlRFaWi66rvoqzchIxUnffFaxTmn0D7NFuaiLi4ZaIcDBB0UiF1KCQgwaHrxPLBmDNa36Mbd+268
755733724rk/eOzZp7r+ygJkrCGlALNFHEew1kApCaVkmoSKLXYy3um6i4dyrY/GpFmHOFOJ+r4P
3/eH/ng66eMDD7594S/+wPf90R233Pxa3lwnKRi00EI8iCApwDgCFD5wjjB1dqRcvqlUOFR4n3MF
kjgna41heSZv8brr84Z3OCiQgwQZdiAM1V/vRgaLTQkTM0wY0e59+2/ad8P+B9Z7nd9//uiR/kLg
D3OxF9m73Eh8reHqs3xc/znZpumtpJAIfB8EQhxFiKMIYMYb7zjk/+Uf+ZFffO3dt73fbK4KtbII
CgKEGx0EreXUcFtrR3KxXGUhvsgOlmSw2pB4B1JNC1Ccc8LPZnitqe9gIVwUyM3SyVqEUp5ArzvA
4lILXtDExvoW7b/h4C379+47dOK5o5+4uHkxCcMIxlgo5cHz/DSzdZYlaxgPd43KdSdD+b4/XGmk
lIiiCP1+H+12GzfffLP6Wz/4XX/zDa96xV8XNpIWCdTePcAgQnd9gMbum4AsFfJl25GIK+qVqQ+q
FQtj9adAFeu4rZwSLhq/s0oJg3qEsHXUaQaEa7UkNtbX0GwtQCwA3Y6GhBT7l3bfc3Bx7+oTp598
pN/v216vN9w5JE/i6Xnet55h1zVlgiBAHMdDgTNJEnieh1e84hXqbW9720f+7Iff++8VWV96FuQB
UWcLwiq0WruBbgIojenIVIQpbB0N/4cRspTq1mVVcm6xWIGIs1CW4bN32A7lUEpYR/15lRJJ2MHS
8jIGlrGxoeEHDTSVQkv48o5Dt7/1+e6RP4mi6HSn02Eh0uSVSZLAGAOl1MsIVYYGLHr9PmJm7Dl4
AGur59A0A/FXvudDH/7et73+lxb9xgIsEYwHYQN41IBA5q6jinamy7QjsRqV4f01ioWJCe6wIbFX
0S4wEmwdE5YU6u1Es8hY0/tn2C161/bPiXAOCii9YbZkTxFIMDQsYjBioHH7/le9V/fsH33jiUdW
2Y/gtQUubVxCI1gCtAKEwbWE6w6hhEhTPS0ur6Df7WHBk3j/O95+8N1vetPvveLW2/YTmHbUjjTz
G1S1nctY84zAfGpxp53IeR1zXnfJUA4tIRfHdKJQa3FpWfriVd1o8/eOnDgSJibBQnsBSRhhaWkF
yQ6nWnbBdYdQGoyELZqtBrYuXsB9d9zR+PM/8P2/dM8ttzzQXFwSMPkKRNgRO5JzhS+8RWX4h2vK
zSnjOHz1nHYix6LBDqWFFVSLEC61uEtGsw6WTTYErezef8hv+KtPPPnYw51exy4vLeLS2ioWl9pI
4m8xTwmXHQq+hNYaNo6wf3FRfOQ97/7hDz744P9rpdX2EMVId+8k7KwdqQ5KMtOEUiI/V8dy1Vx3
5a1z9dFpJ5K11+dl+QzIUb8e4SxRtu9TdemHhFZTyPbSypt63e7H19YuXdjqbCLWESBNtqC8bIca
Xfd9CG1A4QDf8e533fD93/GB/3Ljrt274Puke10IT+2wHckxoatkpjGVNzAXQjhZvvrrbjtRvZbO
aZgllxavHlwUzDJqrxsiWAv4vt+46aabX3f+3Ln//szzz4aLK21E8QCSdno7gHq4+luCOkY87g/Q
JODQwYP++97y1n9496233Jh0euRJgYQBNRWZqmSj/O9inQJLWLtzYe1bjOpsO6fELHLaLM+e0rxz
yarvn2O/NGf3XbZVJ8I52g8CoN+Pwcx0x6Fb3/Tae9/0Vx954tGf1F4n2Rpswn/Zl28ckjDGDcvL
9F3f9t63v+/tb/nJpqcCTmKQFDCSoIYs0w7ZkZxQwTKOIdO8MtR8anGnnYjrWTKXr4Gb5XNQQBcD
4LjByBhKCpgYgJViYWnX60MdfvLE6ePnemEPSlx1GjEG1xadK6Dh+Ti4b//C+9/zbf9614H9raTb
hWo2wEQI2gvjN49tj1mldctfcRt2pJkUBsU62zHKXgHY4d0tXO2nMtD0stMQJ3202wrtto/NjT5e
dc+BlQ9++4d/WqnGit9YmP8Bc8IEhWLbh9fwEGmNQaIRBA00PQUkA0gTw5CEEASRZZlJrdQWUgoo
Jd3+VJIhlIcwHGBl1y5oBlY3N9DevQddneBQEIm/8uf/7F963V13/5hZ70m/uQSoBnQYwzIg8xWs
KMuMuQcB47KGKAj6WWbZMcVBMTVvEYpsXW43KlMXYHxttwWb1zQ7lIslq5eRUqXB9H8u1x5LnG5o
N6VYweCaYh0UyGRi6bSSpBtPTi+Usn3TStNroLNlQEpA+h4uXDS0sNC6cf/K7vPfeOjRh7V3iRtN
hdXVC2i121hcXES320Gj6cOYBC6zQu5tkW/wlu+mCGT+pXYJQdACs4WxEYJGagONQg1ATrY+iAx8
r4WV5V3wPA/dbhfrnQ5iSMjWwjDcuLxL9zDO3wGcMclCCHS7XRARlpeWYKIQZDTe+IYHDt5y06F/
3Gi1lOd5qfYpc3wcTsVKylQFovqYaco9Vch0dSkQO7Rcc7fvKLXYMIP8N2d1d/sMJNbAWkBIQAUS
rWZL3XTTzX/3gTe86aAxQBwZLC2tDOdYESFckCMSgIl5LoSA4S5AERgJjNVp5LEQCBoegsCbpFBS
tWAMEIURYBlBI0DQasFCoRMl8OUoIcblxPETp7kdGECv30ej0UArCDDodrF3ZUX++Pd85/95392v
fEcjaBHFCSDTBCvaaEjfg7DTtHfT7FBFqlWEOudYYLqMBNSzhC61dr3a2mkncigdDKkZfOlqtHiO
SWdJ7KgMZh0ipJBAHGmQVKBsxyOvAVK+3/Z8L37s8Nc+2+30eaG9CAaj09lCEKRZlqzhwu4sU/qX
7TVc3Oe3uHm2RQ+eL8FI7/GUn3FqGkqJya/fai+j2+2ju7EODxqBsIBOkDCghRruKJ67yxcRa5YV
II+u9DwPDAM2CWw8gGc0Hrj3noOvuuOVP9z0mgJRku6emX0lAZnt9l5nhypN/glZqVwwxThbJyOJ
uYrbklEvoxim2pJnMJxa2FFI1BYXsIOlrGX3gHw/7ekl+8w6669hIIwA32uKO+561Y+96p4H9lvj
QSeANSkS5MGq6TytHyFmAyLO9vhmMBsYk6QZuKxGs6UQJ30MBgPAemDrodsJ0e/3IZWokKGgIDnB
Pbce9F5956GWsrFdv7RmtWZ4QQukU9eOInu3HWolIKCNhhf4sJxaJfRggBtWVsQPf/f3/N37b7/z
232SZLSBYErzkSNdvdMdNoBaT4fccjxN8UAW9cg0Rd2ey2HO15xPi6dniCeqpXCOSe+ScSy7DK/1
C4ImdiwYVDs81tE/YkBbgpQCJFOEMkaDidBoNFtW8KnDh595uNPdZCEshGD4voc4TqCkWwNYnss5
4RjOdzKII6Dhr+Dmm17pHdh/KIjjhOOkz+12MIlQsU5waP+i/J73P/j/+MHveM/P3Hf7oTuWms1n
4zDpnT19nhvtNKdamc+cFaEk0lVUSAGpABiNAIS3vfb+XT/wkY/8/O7m8iJBQJBMU4CBABIQJGC1
haBiRG6ZMpVV4blSojCJh7qEEjJVOrkWkamMdNP0vvUIxQ5XEetg+dxqaYfrUL2vHAxRvRzkYhkd
7+dCaBePozWn8y3TE0mZGotBEr6vxMLK8iuPHz/+G+fOneqRsCl7xgxrGUJ49d8O+XY72V5UDFib
Kq2EkJBSoduJcHD/nfSWN77/pg994Ad+9s1vevAvtVqNwaW1s89eWjvLk3YoofG6V9668gMffMf/
/ZoHXnXPHTfue+urb7/jB5baK8fXzl86OhAwRRZv27KUIajAy0LbAcEWh/bsoe/8tvf+8Jvvf90P
U8LpmygJMCNJkjRPgOcBSZJtXF2Y8BPG2ZxyFs8XZaMKWWlqEpdtItMsdiJRP2FdEa+u7Y2Mk62s
779zy07Hp9aop1Bzy1jM8Px0UTbGQigCRGpQtgDaiwuLvV73/MlTx74aRptMlGZF8v0AxrBzrlaJ
MFJK+L6PIAhw+y33q3e94zu/99ve/T2/d/9rXv3G22+74dYgWHr36bMv/NoLRw73Jr6+IE03Htzz
9hv3Ld+ErQsC515Ue/btuuUHPvSBX/vLP/pn/naj0QjykPTLyTBjrUWgPMQ6jWHxpMQN+/e17rnr
7r8jiCTCCEg0wAxrDGKdpBWVmnxepbauZHcao0QTbzulvuvaPOCSs65v2HEtnovlIwGl0smexkGl
9XSSbeQByLvuvOevHzhww24p0uDDJIngKf+yQuTzjFu+76PRaPh/6iM//Pc/+P7v+fU7brt5/8Ya
5NkzUIG/sO+GAzd+x/LyMk1q+WIr/uqf+5GfumkheGWj2SarFqA1k6KBf9eh9jvu2HNL+8Vnn/78
iy+e0jYI0NcGljUWmz48E8OyqJ0u7UYDJy+ew4FbD0H3+2j1NP7Cd/3AO97xwJv/hjFWSCkBmVIG
IgHfa6R2oMQC5I9sSGUfvIk9bousjyicK+Tjq7InDe1IFddQSAAy9vxs61CWGPIiU4q2LqHbMSuz
TKnIvL5ZpB7gLAhWZr54dTIKUEtBEqq3AxnUi/VapGzftGJQf93lHKsFEFnAEAFKpcoMToddpFsg
U6DaCxKNx//4058+HASW222JzY0NLC/sRWKS2uGVCKAkozfYgOUBVOCj1xe4+abXt/7sj/6tn3vD
fe/5q1J6QZTE5AcScaLh+z5pHba/8IXP/vrEkrjQblMraLxaSkkApXZQkrm6N7jvlXf9jT/3Iz/0
Tx64/zVNM+hj78oydq3sxlavDy3cKZy01lhotxH2+vClwk033ihvuenQ37HWqklyfLl2pOHsK9S5
gqs/T+mXY7JemVjSssxWxhpH13eYwuw0uPqfaAPle2pl957/+eZbb2vkDr8kFAy7KRQJjV7Yw549
e7C0sgedToR7Xvnq4Hu//4f+4x23v+LPMMGz2cJkKY1gJinJazTvarQXJp1jd68sq4V2e8lXKltt
s9WYBEAe9t2w1//2vbv++urW5qX1Tuenz3e6cSwkLAtEmpzetlprLC4uYn1rE3sbAV5332v23HHb
7e+ATYXNVFc+DXmKf09TfaN2ws/PVuUhGkXZKxsfuE0HTPWLjkspUbzMGGnFcjCulBaOt3M6v845
eq76ThnLMb5JEmNhoUkH9h98/Wte/bq7PvelY08wR5BSDjNq1YHmGESMMNEwWuDA/tvU2x983998
0wPv+BHlKRV1MNSopomICcoP0GovLCyv7JrUse5ZXgkWmw3fF+mWjOkmB5Ra3FgASR8UD4L3vf2t
/+CHPvLBjzSskRsXLqLdWgSk71xBmBmSBGycQGhLb3n9A9+3a2VXS5LIBmtOO9LU7TyvTBmzCxFS
VmSoCEhTGdeWzEA4rbjsSGxTTaDljH1iAtuRHco5/nAUhx3IMtcWk9mGphUXzNv/xGgICazs2rtw
z733/7jntUWiAZIKxjqtdCAyaC0uYPXiJpib4kMf+sEPvuVN7/k/BiF7SYzMpZFGbDAEhCK0FlaC
5V37Jpfr5Xar0fICSaChtY2tBKwENKV7LsUh7b9hX/s73vWOf/uBt7/17oO7lomTGEq59fySBEyc
oOn5WGktqNfe86q/Bm1JZHn3Jn3eqhxYXXakKmQq3lMHsygNpnlrYAbDq6gt7gmXqacLXg9jMUoO
hHUZVuvkJ1doxSwIYVJz/tTi7n99sZSK214QiJsO3fHdu/YcDBIDMAmYGVhiUhJRbLCycgO97W0f
uO/d7/7wrxw8eKiZaIs4yTiCTGZNx4wACfjNBdVe2jXJobX9RhAoT4ATwDLYAqTS1ZVYQDOnO851
erSn2Tj4o9/73b8UW/7u3/vjz12w1jhZPiEEkiTBcmsBr33lq266Yd/+O9HpAn4mbE+oqeuoTgVl
GuoRaoy/tTNCzHY5V0pMsH/uCVcHLkVU8fKQ5Sus/E5/vzlZQuu4wzVpnVsEYz6QUiKJ0+O9e2+4
6a4777373IUjTzAMrOEhaz4NojhBEgPvec979373n/qR32439+4ehKBduwJ0B+k9Qlgwp8Gc2uZK
EV94QWtySWwo5SkSlAu8khSEUCDyAJJg1QBIIekPgDgRd9126I0f+bZ3/18P3PeKBiUD5wvnhuB2
o0nvfee7fhRCBQBBh1WJ3ot/Z19iGKYwzY40pb6TfZxNbW0z6pC64mBEXShz23GwRG6Wz03Bhl4N
hQk4POcqcLCUrv7NScGc4+vsP9cW5XmIklQUX1za5b/6Na/7sVZ7SZAQM62nRgvc+6o3NN/9zg/9
8i233HVXnIDCUKdONiJJ5aZMy8oYsbKp4sOfRFchRLarIgFCgKRMt4IRAoCE9FsIt/rwWi2oVhPo
D9T9977yhz78/m/70w3PnamdmeEJiUB5/uvvf92PINEEleZWS92M5rQjTcQFidko0+VArfJjShVc
23giZ/922s7kKPPCUPnAQCMguvXW2z/SaLQCKV1brabgN9ry/e/78N945T2veX+va0S75aHRUtjc
CiHUCLGZKDMjZHJj5pY1waEZNTCGBIA2YAFLIQz1IFiC2SDeWkWzmcaDWA3I9jIWiJpvvvG2f/G3
v/O7n/ip3/v9xyEFJ0QYmAQggVZrAbCMXqePzVaIA2jgLbfctbzbBrdywoghoBq7gJ4CKMHk5Mxj
lspQ1Ahmx2N74GZAPJwNTIWsSQDKFM41Z6wptm1Lv0izAtWCQwvoYJrj8szjiQbSfhQQIPe/A9yc
qYtlc13XrvYdZMypBXSxbAkhkQYmAPoJo7F426Gbb3rT3rD76ZOxPgntNdFSC4DxYaKUY2KpYUSI
BBF93/f9szffcPP9/0A0lpXWwPogRqPhw2s00OtrkGdBqRMP4sSg0ZaIBsDuZouaScXwJkkSJ9py
aoIe38tUCIlWewEUBCCRpb1NEoAk3XTTTXvf8ua3/cJb3/jAcqA8wGgsLy6BAHS7WyAiNJo+PKnA
xuLAgQOvVFI2gFSuGik0qti3KsVD9neloqJUn2evP2880k7HG80CxTl7Jdiwsfe7xnYs1/gSIfMt
BQgEKWVj34H9r0+sJeUHYKtgLRBGXZCM0WwpdPs9GOvjgTe+d/f999//GwcPHmwpBWJGFgcFKAU0
GirzYKchi5mDMQnHNp7kMQZREidGW2vT0ErO1LKCUwdVEGW+86lgloQxMBggaC+JO1/5yvu/78N/
6u/ecvAGj6MEki2UyFZ9SgO3msqHYNCdt9/xQSlT5lJkrOVo8ZvBG3wmtyFRj0wT9d1aMpda3Kl2
d2mx5lQ75wiUy1PDSTjjhHeHVzhkLGd4SH1xIaxThhMAKRp+Zun54vbb7/gutkSeF0CgDYaE1hGg
IsDXMATsu+FO/9u//Yf+1c233nRz0BQUJYC2DAiCtkjlMk5ZvJH3OYEFYImhreEoGkzyF3Gi48Sw
ISlSGUpnaqRMq2ViDSILIRS8QMEkBtEghlIWstFUDz7wwP/y7NNPf+zcuXNfPL+6xmqhjaWFBWhr
EcYDLLQX0A4a8s5bb/sQkSBjdBpEKDJEpTKlKSHYRPhFDTJVIty0+hlL6JBjXIZFV+5vF8vCLi2a
AyvyVdOmjQ2RCdlkdmGViyWcN3W4W0voeP6MWkLmXPum6OZb7nhQeU3J7FlPtWBNH15DwCBCP+rg
hkO3ibe8/YMfeuU9D/7p2LI0SdoLz1MQkIi1gdVZ7B/SvcssMVhQmukYQGxiDuPB5PCFcZRoywkJ
BUgv5TEtDd15pfJTVyShAL8BGbSglJe6uScWDab2h9/93p9/15vevEeyhY0iSGJEUZhuiqUt9u3a
09q7e8+dAI2s19aCjSlp8bIlZ3iubJMqUaKhf13F3xDjdcrIlD1jXjuSU0vFVFvcFNLNcpUp09i5
GQzv89iBXBTOBU47lqNYC2hrU79CkyLB8q49h1Z272tpmy6osY3hBT6MFQgTwmtf95YbHnzXB/89
VCPQ1sCCIZSE8gHpARAEkgJ+I40SZpG7MwmkwQ8WiY5Nb9CbXI63un0dxnFoQICQEKTS5S7PniEE
mAk6joFBDBgLqRQ8lcZJdS5cotvuuvvu7/zAh/7RG179auUJQqfTgTUJWq0WbJzgjltuvaHh+W1k
rkZ5FK8Zri8OGaky+K94T41ReKL+pHG2/oPXy1ipfWJ6cbM89Sylq35uHLWc8vg5Egw9GRwTfl4t
3LyeDi6EcbZPgLZmOBZCAkoFzZtvvvWmJLZIeAuWIzB58ILduPnWV/v3v/6d//am226+cSsEkadA
ngcrCIME6IYGodawQgBq9A45WAAm5b6SXq8zOYM2tjq21+uvJ0mS0fdClCwL2CQNfzeaEYZhilic
sodsgaYQwCCS99/7qh//yAc/9Jobb7iBrEkQBAGSJIKNErrzttvvs9pIZM60QogCKzWnjMQV9Ss3
W6tGpqGdaUpxUhCXWtwxG+b1JBhOzgoN3ywKinntQHN7OriKo38k010wU3c7CRKANixuufXOV8WJ
IYtNNJoSOiHs33uneN+3/+BHXnHPG79zEEKIIGOVBWCYESUJEqNBMrVhhZnBmDm1cxlOXfNik6Af
9btbva1Jlq/T69lBFL6gtR19lcJtWmso6SNoNOB5fmqjyhxptdZQ+/aje+4sgqDRfvMDD/znm2+6
caHZbKLZDLC5uQm2Fvv37bvfGkPIMskg83EbGXbnkZHKCFeDTFPrT4fr3Y50rWGn7Uyu9oUADAxE
usZDSiBJEtq7d+/rrQVIhmi2fRgraM/eQ4cefMcHfn7/gWVvdX0T7SVkuScAKQlKKTSbAdptBaUo
3beMM+nHpsiUhuAbxHF8IooHEOUuCeHxi8fOfnlhYRejl4C8NixLYGEJ2pg0PgnpsieFl8pTiQEM
w/MC6CiCai9Br/fp9l2HXvvXv//P/63XHLzNP3PsBA4c3I/FXSvUaDbvWVjaRYg0FCtANtHpxRAL
e5HuzVREhGGkTVZcIy5KJV/9MxnJUlZGq4xhnZUY0gLSYixltC2wHBIWEhaCLAgGIAMDDQMNTRqK
022q8vq5cJz3fuhkmr2VQRqDlBAQC4DtSCOmASRZiSktxaT6lgiaCIlISyQJhgS0EDAkkIjsOPu1
JKAFagsX5DkNQkJpibNCkCBIMElYkRYjJBKZlnI4vCn0LxEEK0RtcSbydJAoQakDb6yAgQecGwBL
N6xAk7m/2fJoifbizIubdMdr3rT0wR/98d+JlhZ3v7ieULPZhOlYKKUyhEltVNamgYvGpLtrxiL9
5n6mtFsNgaWbF/Hc88//8TL5k1o+bRiDKHwMTAwhaLhqW06RB5NUq8huKSEhlAfBBFiW+/bu/d/f
9fYHH1+Leh89eu60XmkvY2lp6Q4YA8QWBgyZJGnbA7fr0jjy1FGZOi1fPdTbcTJtYMYOVy27NtOq
5cvBsLvsjlgqKxHK5yQX/q64v7L+1HepeD7q65fb4Cnt2tLQ5P1y5bafN7f6wACs0o3jpAQizbCa
sGtlz82+16DNzR7ddue93n33veGfLLRX7jcGJIWXxrTCPTtISRAxrLGZzQswBhyF/U8nOppEqMRo
bHU6J60xLLI80Wn4hh2xZHWOp4YgKHPziDQOLO9tfsd7PvAfumH0+C//5m8cl20Shw4eOgClAK1T
lpEI7UYTrE2GtC6Y7vLD4Kx/uXdFNrvzc44Pkqu1h4PLkzacXN5jZEqATDsGzjRZWZ3cbpT73WHK
ZCxPkjotXd4nW2ojf6bI/O2G/S54TmCWiGCMIydXnMufm58v9lHw6HpVO87xd/XNcT00Fux5CLVB
s5FmMtZaYv+eA7uUbAqWy+KBN773HQ+85Z3/08LibmlNGukLO+IaakFiaNhFZvCNY9hud+tIFIU8
aYeyjNWNjbVQa9NqBDL1khCAZhBkYWSmeCLEdsjMstagRoCbb7vrwDte/5Zfeexrj37w1KULeqW9
uJBGAAOQBGssfL+Zso6zyiFDlXj2XM4RIUea4pcfeYW7ojZteQLmkzKz40g78pgw4JQFs5xl+8Fw
PzGT9cMyj00+YcX4ZMSo7eJQjmmSCueo8NHHjLdTKNXEOQeFMJnxiocIOD4WVBifMUqZv0cBY/IF
YTtBidZBwlwUKpECyiNEcYh2uwkhAWsZrYWVNsmmuuXue3a/6vUP/tyhW+5p9JM01EMIINaAp2ZD
aI1M8eEpkALCKDSd7saWNdHk7NUgXFhf7/XDMMm1fFLKTIVSkbe7bOvJXJWQae6SMAS0pbtvvu3t
3/XtH/zwrtZSQIltINIAASYxCAcxrDHbM1RMUTwMg+Fsaj8bU1tbmsHTwbVCp1TPcBZYyJnnecGO
lKv/bWY3yicql5CrrIkbKzRCmPycpVT7lGu8xrRiBVV58e/iPWYWtXlJvV30XrAEGJGW4d80fs/w
XpFdy9os1psnXko7CsnUUyKxCaxFmm9fELRUjWBlz+Kb3vUdf2P/za+4AwKkzYiTSGyGKI4SmfS9
tDXpAiOAfn8r7nQ2IyGrPDGVxNr6ZrTVH3T3Liy2QanyIRUAylq40sQG0nukBKRM9fk6Abo97Got
ive+7Z0/f+zM2Q8IQwEYQCOACQdpWl0W2RLhwqoqTeCIQvLQSbaMbCJLUlJPAW02m8rIlLNOY7FH
eThD4aTN5Co7RL4RJSsiJoptV6wZ5WuzykiCp7BjpbanwrT6ZQo4pZ/E4xRteH+FTFk5/g5/SZem
kChNwaOEQBJlU1YCoVb+ba9+zTvue/2Df9Vf2C16EZBYC8oir6EsdGaYrwPNKTeiwcg4RXR7nc1e
Z8OoKoQi38NGt2P6YXjOGj4gpAApL0XhHCUnvsxochsA0g8AY2BA8IMmjE5VV3v2HFj57g99+BOB
UBIGgBeA4gjNZhMcakB5mTv1jFChGDFlmQl5FHD6hV2uPXnOhwl2BuNKAc7YmzxxZJFVG3pqIUem
EfJNKBUKclb6AUbPAsaPmTKWr4aC5sg9kplKyORynaqqXzhGoa1huwWWlQre9kPqOoMyZNiu47pT
sZKkn76hFMIoBKEBLYFYCfn6d7z7Z5f3726ZPAmsEIh1hKDhQzUE+oN4JP9Pe74kpKGBAiwBow06
nc0Xur0tK0SFwCKEQBQlJo7jryc2E6un5sOb9ETQxgCCkFiNxBpQI4CUEmEYAnGMV7zugV3EAhzF
gNZIEgOQRBynf7uhaJsCKpNLXm607pwwS273WaBIBbYtI5X+LlOmWexE0xxs83Ncoo6zaPlmDUCc
13mWE0AYIPA86ChO7UUEWKXoFa95zT5DoIRTlyLlAdpEgASCJlI2EagtgnIGLF14jTEchv0vRtEA
QAWF6m5dxMrKXv7a09/4g/tfce+PITQEEojCGLIVQJnp8gsABL4Ewj48EDwpgX4IsEC7uZDee+5C
qi1sN4AkQitoAIMQgecDVhc+VtntKBP6Hd6biosUhmFhxiYa2XEKVJ50IsPpnPfnzCY0dDDNZh5X
TXpBMIbHnFGHEzFbuYe/U1TfZYpVRqp8eMYoJ4prnKitLwuzOu9fcaILHrGmVW1QmWcrIwlPuZad
d3rMz8vytYEIAIyEt7gEIN2TyhNNmF5myVRAN8+f2lpCpIFoE/C9tnPdbelLCO0erHk+pAH2+ZoH
J5/6rF67xJ5oTyKUUgrGGJy7eOExSJFY6EAYk2aKzTVmKP4WR04gFd0Kf287XqmURmxCLe6GOjtN
pe66Sm19jexIs8CViHeaZicq40stBaqQ48oTsqzlm5dRcL7vDDJi7WVyXSdokzoFBAqAhblw4fxh
wKYZxMsVPC9AkhicOH7yvBWyK0kGMBbKCwoq53nilez43xO+dzXe4HCzVZyp9itlEKCSXSmeu9Z2
pKGMV5BfuPDAXNExi52nqn/T2Mly/WmKiZxCjclmXI1IQIG6Yzbkdy2Yrgnvyv3urO94viGBxFoY
IxA0Abs16J84fnSVRBoLNoFQkgR0onHizKlBd9A/tuwFe5gBkhIca0BkQttOxStN2LkIRarGLjuF
HTdsFuOC0us0yWIVheqCMuFa2JGKdau0dCgrDQpsos00XHVaujEtJTBBQYoOX1WUdGi5xQgRi4iS
Z/+dYGUx+fwqMMJx3YVxjvrauSDXA6sgTcrCFp4S6Gytnzh78ngis8VwUstn0wm8udXVJ06f+fR9
t9/1gIc0LTPbgpZvKltXE68EVGgJS3WKCDkl713tCxONyxYYfxwXP3h+3xgV4DGNWVFbV6dSHj6n
9Lyy6psLbY71b6iW5/F6PD45RZYMJH/GhCLB1b8psmMVwg2VAMXxxchLZIzKDr9YQUbDuLIDSO1T
9d+v/rqrvjPzrKN9F0Kz9GBtGhYPC5w5eeR3O1vrvKulYG0FQhnD8IRCYhL++hPf+OjtN936t5Zb
DcVRDIHcLWg7MlKZrTO1WsLpyDSbB8VUX7SMitjSCl1UBKTnqDCJ00auph2p3NYYdSi1U0vJprSZ
h6FPsxMVF4biuOXnxxC64r3GtInFcShxANNgXl8+F4Uxc9ZPIMFINX3hILTPPP3kfxPQDJtubjGB
UGwspO/DSokvP/zVw+9/x7s3l9uLe+I4RuAHFSxZ8XgGGWmmeCVgGtWzXG/4ZZ7ODg3FkyoKkT+a
cE3tSGMUrOgCVJZRii5A2UywBChQLWUqrsCVdqKi3FiDOMP6ZQqW+zlSiYJlNwmXFm9OhDIz2tmm
Xnc9n9OdP4iA3tZm79mnnjjWbPgwNgbIq1r20+xGJCVeeP7IVqfffxoMaG2yeGBgZ+OVUFEPAM9G
oWzWJhdC3m2WPOVqxSvNa0e6Wn2sshNty85EM9Sv0PLVlVn6PY+dygVO16jMtQ0EDPq9p0+fPhUG
gZ/tO60rwje8NJYkkRYDYe2xM2c+d9vBWx5s7zpA2NgCGrlYXRRftztRi7nzsvr5yjjUImWbCOcr
ZTYBZGZHmiYjgEfe6sO4o4IKXBVZnAIFG674dnRv2n62r2y2suoSoS0L3zLzDc4pZb4ijliqChmu
0AbndqTCBBprf5hMZvI6A4in1BuybMXZXUWZxlyrJikQldWIpXa4ND5cuD6bc249aKdnWj3WuFyb
XDJY1E+wfKPAxdWLfPLIo7+/ixSrrRiJBAbNpMJTggHK8vBFScxnzp/7vGFroXXqq57eVawx/elV
7knFUXfVnzoo1cfD5jGa0BO+bBX18nNm1vanIBMq/h5vn2drv3DNKXPVaBWr2i97LEzzBi/LbrlM
VVm/zI5WjE/xdyeLk4KhvrhAKIUkARTYrl48//tRNODcnKSqZCiRJUyBEIiSGC8cPfJkGEdRi72W
9APARtnITNPiAXUIx8NlShSWLMorjvnaMaGCNXHEKzHGfMtyKpWvtqJwrUglyshUliGKck2dHYnG
2uepyDTNDlSF8GP9mFLPlvpXNhnMaieSU2So4viO1S8tWjn/MuzfFGXJNHDJMHPvTzWnjIaAEIUa
KtHxmePHjoRRFx7S5JcSXgVCGQYjDQXWSuPoqRcvrne2ziwsBXc1g2ZBqp2meCiO+JR4pfxcxlKN
2ZnYjn/s0kAU43HGFA/ZRBYYR5gJVXVBbQ6UkK/Aok3La0egmeKR8vxzXFDDMwFs6+1Ixf5X+dLp
8vNKzyYqIW4J6Vx2Il2YUPkiNOaahIrnFpByqFafgrDCQQa2s+FcZf36y26lhqt9D7C9EOh1z62d
OdVltmBFACSkkRV2KJMmVJANBQ58nL+0mpw8d+YLBxf33AmbD+12tHjleKWMOuWUqUixwJkyYboM
QHCs0BhNUjuGIOMMf5ktzCnZWPuYRBTjsCMVF/IcmThDastuO5LTfgTUIvTQjjZFy2kcdiKa0nZV
+MdwrEusYV3/XBN23us7jXCxBISJ0D19+o+jjUtGeQB7BEokEFcIMIoJlKV8EoGHTtjnZ154/hNQ
ktNYpWnINKWUklamgXypcD7aBXCUNSjdJmZU1w61c2kxTGO7+DGPdvKzTEP2Lt3tL50iNnt2kV2c
QKb8g6M+r51Lphm1X0Km8j0lZCproqb5AupsUmjKNkjj0a9GToFHG7CVN2TLZYliYKClUQAgBGDl
iKO3pRjSoawikOp/xOjvPKiQs/aK7XOGDC4ZxlkcMpRhri3O+o6iBUBs7Ynnnvkl7vdYeQRDgFAS
Qle4HikpETMj1gmkUAjjiA8/9+xDSqkIxjSRx4vUejpg9PcQck+H/O98GRWjY4jJqNZsho7sPPXx
SqIkM01M5AIyoYhYhZx25Uk8xjJxPYUsIhPyYxTZznGtX9mOJEuG0wlWssQCTsg6jv5bW28nGotn
KkzgMkzztMhlxSLlrurfNHDt7jEvhZn3uhZAS4nB8WeefRJJBJYJNBgBtUCGq335yFrESQLrERKj
cfbs2fNCyROc6HvGc6hUae7KRI8wVZM3p7avCipZkyE/z+MTtjSpZmqfprdflLWG7fPk/TO1X3Nu
GjLNAlXKiVm0fEO36Kr6UxQedZ4Us/Zvu9fnVVq4wEpAkXjk/OlTHSQGliwMLOALCFjIGxZuHGPS
jJKwWmPRbyBOYgTLbWwOOmbX4sLKa1/7mvfqMCHRCGC1QX/Qg+d7IN8DswYzZ0LxkJxgRH3Sc8QS
AhJEIrWaUyaJE8MKhoRMk7JTZvHPj4evlIeyj1bf4jFnKS3GrPf5QbZzNxfqjQht2hcSaeEs7x2y
X5tdT3d8HxUWhWMiJAxYpPnoLNJzRqS5LGyW1NPS6LwtP4tT1szQqA1DGVs7jBAuTNAJxc2ovfw3
P+ZsLPOC7F1ROJe7JuXUcZieOR8zO2IzGSN2cyiDcv7NR2NSztXHqCli7PaJ4spLUfw2VYWpvn2J
NLWy9QiJAPomgWxJeC2gHxnsHwh+7FMf/9vHH/+Tp8zgEhabC9ChhU00ZFDhOsCUbUKV2aJMkoCZ
7fETJ36ns7UZGmMAm+Yj9zw/vTdJoBMLISXGd0TPP8ToXHEyVNpxCgM//AjZF80z6oyplIt9n2GZ
rlLjls8VXYpq7VAVLJ/z+RX3VykmUHFfVX9dMleZBSy2W/ZoKLJ3PKU9V/tVz9vOGLkiZp3j65CR
ZrJTZR9fyjSCXet0GzRmRmd9Kzzz4ot/EkUh2FjEcQySAlprMMwkQhnOtu1gQBIhSdKw4McPP3ny
zPlzp9Kb0ns9zwOEgtYaWmsg28k9zTLEo+xDxXMFZUNOF8uuQUVVdzHHQb6LeS4fleOVJiZFYeJU
sS9VdpIx+YsKx0NFRXpu2I/CcVnmmPr8Ghms2NbwmEcTqmpBKMtcY5NjykTKx6w8blxxrezWU9d+
1T2zugXNVFBf5nVNIgkkSHfvEAqAIGhtoHWKXBsXTj1z7NmnNjmJIdI0zwj85pAAqYmVy9qhT7nI
1NxCCDx39Ej/6JmTn37lwXvuAhExI83XJ8QwXVeuxRtboggoKi2Y7ZhatxyvZLJRY0rz3SHbyzRF
Rhpyk5cdr1RkmXjE+hW7jApkGrZfErKrZKo6T4fcZsZVY0AAO+xIsCU7WGn8dKGt4QJRgYRFg3je
Rtq/cU3mGOXJvkvxfctUWlD1+1f2oQJcVMwZXuGo76RyHmCidKXM3ayY06VeSsGb50781vnTR/WK
MAg8H5EmNBoNhN1OtaeEthaK0l0HBQOeVCApsNHr6BdOnvjveKP4SyChrE0zlSkVQCkf1qZb24xr
8fI3HM3UVEVe+NjlgSgOPFG2w3Z6wRJAds54pYoPXDY8ViFT3r7Jcv9NtJtPyDmfD+vO/Opi6Vz2
o6prlQsOJhcNaesXFFP6u64PVTCvJ8PcdioBsCQkbGGNhAFDZduCmgR29dRz/0N3VjloAVIKWM1D
c4y1GqocAJuvnADAxsJrejBsoQIfzx4/8sTWZmdrcXFxt6A09wQsIKSClBZW8wRFKnuYV8UVjauN
S+zXBMKks+hy45W4QB2G7fNowhZD4IvINDKcTn54nvKsqc8vvG/5+cUQ98p2xcj4POwSjc5NUILS
OVG6NnyPHAHslEUB4/eNUdBi+6W/J2XkenBSqHkRxvH82CJTFAHWpNvYKiVhDLC1sdE7c+TpYw2k
SSVSeSvdlQMAjNYVSgmRansEp+lmlVII4xit5UUcOXF87cSJE18fDAYQvg8hVLrrIABBKk3ZxJTJ
G6ONfUfnMDSUMo8ynI6dy2ZSUTFgMmY9X53LiJYLkmPtYmSQLZ6rlUGKMkAFMlm4+19sp0xBqmSm
8mQrGjDza9OUFpV2KmBCLiqeK25aVja8pvao8b2acoNoeX+mae1Plb8K/d3J4lJquOrHOt3qk6RI
tX1gCAEMBiHOnDnzxIUXj4bLLR+wMbSOQVIijBIopcBckUY13UE7W+2NgSSBOI7RbLdx/tJqcub0
uV8NB7GB50FKmRoKLQ3rZK2MfkvxTrPEK42xXDOuPNsBV06HaVD2y5tAiBn7WOerN3PdKe2Vf6eN
X1nLVxTcy/fzNtqvet40TWPl+zmKC+bV8kU6AQRByLSzROk+umEY8sWLF/9NZ/2Sbbd8COKMeikw
M3zfh5QVvnytJB2CPjRkM0DU62NJBehvdQAAv//Y5z79wR/+3g539UrcNwiCFqAIg04HQbsBFdvC
4FlYFJxdCRDwRi+e5eUijI4BlVLHrD9Usinl8UqjDQ8pM3mkUZRGFgaWxz+EnTJJxlb8IcszHgfF
6SnoKXJaWXScKkPJ8edPyHAZTzNNTjKYXp8JIMO1E56ZKtsdjU3Oro+/Tw5Fliu36Y05z07p99C5
uUaGZAKkqT4/s7e647ornMoXPjakxgIJtAYS4Qrh2G7gNil7+Ce/9sklSjDoJoBYAPmAZANJJt1r
THjbd09Y31y/8PzRFx7OWcP8LUQhu2wdDz1hSeNcyM/PldihwrNdgn/x+UU1dvl6HbjsRNeDHWna
ZKz6LbdnafJZE54OFeM7QeHKz8BISeFsv6b/ZUpURiYXBXKBU60uCh75IrWB+ho488ILn+l0N7uu
9reNUGcvnjNfefgrv5BYbaCQLjkZQs1iZxq+fKbuHu6vRJjNzlQYGJSOhzw6F1bmgq9eKgeM5LPc
1pPvGFg25jqfV3HdZUca2rGy543ZsQorfp2dxyUnTZVjaHzil+Wn3Hm1Tk6aKh/VtU/j8ltd/4fy
L41kuPycJk634KwpLpYx/9bTihaAFAKaDayXfsRmR9vnvvq1n97YvOgklGoWrC7CWvcSf/XRr376
A+9+39YutbQLwsJoCykljHXH84zy4tFIO8e5UyUNWYZpdiYw1dqxuBCvVBUPlfcrb2+CumRquKGd
aPjc/H3GWbLcDWqEYPV2JOIp8VTZOZcdaRhnNezv+PvI0t9llnTau09Te9dR+aIhOQdR0WaxjTx7
/bT+qynPnXWeuuxUs7CEInNGMA3AxoDcXNt68euPPBIN1iEd7jgK24TQRnjuxHMbx0+f+EL7lnv/
lE+AtRbkKRgdAeTX25nyjufG25yCFIxotXYmqrfDTMRDFRAzhbRSrviY1s6s9qTt2pEs03jdkt2n
qMqulIGAaoTMx6kip8MYchdmVJUXB6a1X5oH7Ojn2LeYpf0hwvFk/UIHnNvdOLQ7xpEoNSFCw6YL
o24AtjdA9MKxz/WPHu8LhAD82vrKtedpGSgALm1dMo8ffvxXbt1/84cb7YZkpGTSgCAcdqbyS5f9
p5z7K2WINTJ0jqjJEDELbF4RmarkmarVzymjFd5nQm3tsCO5ZKbhlsbDAR9HXsPj9csUcGrm2NKz
uHStSgs4fI9C/8Y8RSoQqei8Wykrlb7FcJxyO+SU9xr2z4Uw81IoCSACrGBoCZhB11547MmfVRvr
hnwD0vUIvW0ZSgQCoYn4sSce/eJWt9tNtM709hUfo4KlGmbSyWQkHp6jIfWpszPVfezi86t8AfMP
Wt7dr3iubFcat5HxxPtUTY46O1K5vWIQYx47VWtHwuTOhcVzZRlou/56VXajYntFb+9hXXEZ7Rdk
rko/uynv4VQqoL7Y4thVFM48C5gZiWAMelvdk4994yutOIGQLh3hZSAUCQELg+MnX7zUD3uPGmNS
lXWmHZk1L97lbqVUa4cBJliI4nXrWt7K7ZHjeTUs0WX1v+K30q5T874uO1KZBavT8tXZ6aripSpD
4qvar+l/kbKXx6D8Djui5VOpexsAJGwRR9FDqy+e3GqAAXLvXzaZU8LBAyqlwL7FmbXzyVeeePjf
337r3e8MB5G0iUVACkmBUuWavGFuOgAiz8GX6iBGiJV7RdjyBxu3BxXNJPlAGxQGs2ifAtKYn8Ip
Y8aF+vJHtaUQk4nrxQ+fayOLj3bIeLnnMaGwKhfGV+csbeFVxt2XChsqFCdQzgpi9DshdxUeNK2P
VEbE8oTmeoQox2uV5WhbeuF8uuWPTRx59Vzb1RgHT0dUT0P2dIDzbUAtB1i8uGYHjz70b7tbL5jG
XoW+UWjVN799CtXpdCBlGgT49DPPfKYXDdZV04MBw2sUk0xWI2adHWfWvHg7Ga80K0yjsE4ZqdCf
8kpelneq+l1plyrcW2kHmmF8qmSoqv6VlTZj7VX8PWFnclAIFzgpzJwUrM+AUgQdJuhvrvVOHj/y
habvY9DpQbp2KsBlIFQSJWkclAQeP/z4xrGTx35LBoqNtUMBuqjazWWgXDbJ7S7DAc+OZ8mLN+Tb
C/aaKx2v5LyO8VXYDM9xtcBdQqZZ7EkT71+Saco2oEq7kSiMV0n+qbNzOfuX2WvyXdFzRUnRBlRl
ExruMu8qDoRw2pnmRLg+OI2DGnRx6djRTx59+snNpu8h6obwjFspPmmHcmBxMwjSjywt1npr9k8e
+tzPvObe1/5FVsKPEozZfMqJ9ovNlw2vw0nkyIuXx0SVkSmfrFciXmmCXeFqJBkapceSstCw32N9
KNrNMPp7eK7MKpWQadjfKf2vk3GKlGjCzjSFMtb1r44CTbhGlfrvStbvklKcqZRdWkBH+zogCAv4
/b558YnHfnLz7Cm7SwhIIijrOzcj2DaFagYt9Pt9JJwgWGrgT77y2aNnLp1/TjUCRImdikwjTcpo
og7zF9BoFcsHHqhe4YcfqYRMuZas6PmQr6BFC3mdfWnseZicdMXJPYZMGL1fFSUpa8VyCmIK54Zp
vDAdmYBR+q+iti1vp5juKn+2ocmVOU/xZcR43TKFq+qfRkp9dGFs85RmuuJvnX1XnVOXOSmIBtcW
VxowV/vcAMygB1pfP3/uqcef8E0fiQ7RbLSHfqh1MGGHcrGZkiUGgwGCpg+vpXD01NH4scNP/MuD
D97yi0IKYQrrXBGZipAL9MMBLFCAYqDgGGUqGvaqkIkKjZcQsFq4rz5X3CFvyPIVyMLIzkHZbomU
vV/6QMreifI+5MfZHSwKlKDA1g2daouUoNjHqkWmeFz6cBOq+woKNnxOoT3KcwgW2OriGE4zrJef
P3VRcFEYZ0RuPYVwaVtd8VQgwHZ6vPHCc78+OPlitKgISRyi0VqBNgLkoKHb9pSwmZpc+gq9uAfZ
8PCFh774P95879vXb1jas8dYTFCm8ovOkxdvpE2aRKbhhCiwWGVPhWltFxHSJbTXvl8VRS20Meat
XaJ6xedMM85OlbNK36ksg01TTEy0V/zWU/pXx1JXenZMYUurwKWYcLGMrh0unamWE0D0B/GxRx//
eTXosEQCSEIMC53qqGth+3YoFmg0fDRaATY7G1jZvYwnD39j8+Kl1f8KxwIxIbTXTIjLgSsVrzTP
8yfeD6PjIpSpxsxaror2ikhfaQcq93OO/lV9r/Ii4LKTXc9aPpMAFJsnzx45+mIDBE5CCI8QGQM9
wx5lymV3KoOwHlr+Evr9PjzPw6WNi7hxKbBfe/yLv/TqV7ziL9pYNLQGgiA1ufQHMYQQ8H2FKIqG
vlT5yw9ZowxIlnbXQEn4RU7VKDumkdMo0XBSV/npWQBw7L9UF2+UCtXZ9cxeYmncNy9x1M8T65ap
32ii0nj/gEoqeUVgxKkWoAJjtvHcnGUfVi3ZmbSD5XO5DsFhR7KyvrqIAbUADDSgBxEWpYIQAluw
iJsSDdb2xFMP/cvmpQtJcmkLcnkFXUUQYRd7VBc906xvf/ahyiBLncTGotlswvM8dDodnLt47tmL
G6tPp7muGdqmk0FImSZbsUAxInc4ABXjW2dnKrKL0+rXafFmuu6QUVwasrr6lXaiCvmn3D5Pez4m
r5fr5tdnsSNVxiPN0r/CuXko0LwUxtk+AGvSQEjle7BKIszeWQKQ62ubG6df/FR/8xI3fAVP+lnH
JcxO2KHSPGVpltjAa0AphU5vCydOHe0/feSpXxYi3YTPGAtjkBmBJYxhCKHmtzMV6ozsWQXtWuHD
onQ8y/VZ4pUm6pcmQ/HcWPs06sNQu1k4N0s80tWwI+Vav3K8mEZF/zC9z5dT5s0J4bJzWaWhM3cK
GQhEEujDwgqCR4B+4dk/XH32yY1ocw1B4EOwABJAUJoyzIke235hqzP3GQGrLSQkmICzq2ftVx//
yke15Uh6KRuUGD1S1VqGkDQ2AYrIlE+84qSpsjMNJ18ZmaqcZyt4/rzuRBBgEdlQU79kKM4Rb7gQ
5Ls88ChRTH6c2+iKKu18MuZq8KHxtWCYLe5oUawzbCevWyhFx1VTnKgV9xef5+qfpvEEOAY8PKdp
5Kg7tZBDrS3qi3GUujTLIABKQ5swpSQCCAWglYQnBfwQZv3hh/714MVjWnECIQSiMIS0Cg2/hUib
ocP0tLJtLZ+2OvWUMDGifgQpJRrtJraiDTx8+GtnLqxdeH7//v2vEZ5A2I/BQoKQ5ub2Mk/ey7Uz
pf+Nkv0XkanIUtWxRNMC14b2pbJht0ozWNHWSPvoaL/8nmXWzIXQVFowSu8HVF8bjk/mrlCpOAAw
9KcvmjWKHUD9gjVvmq+dThNGgYSNNGAsrCcwAOB5gBdZ2POrl85/7atPqq01tNoKMWkM+gm8VoCG
56NrjNMSte14KM0aDdmAMRJREkNKD74vEOoQp1dPxU8/ffjnFhbaP7O4uCCMMZDSQkkJMIFrkGlk
MMXwg09Tjae/48iUG1mH+QCmyBzDNGWUPWcKAkyrP8yLh8IGjDQ6V8VSluWLvM1KxCzVn2ZPmsZm
CkxByKrnUvXzhvdh8rlV4zv2Tg5XBSfC1F9225Fc9aWAZYKwArFJU4+3lIC8tMkXnnj8l7pHjg58
ayCbHkKdphFTIJDVkJ4tZfeahMuQoRiG0wSAnlRpmjEdITQDWGn44a9/7XfXNze6Qo6QgrLjxBT4
2SkfdcTrVyPTmEdCCZlsCRnqKOC06654pbwfQLXM5Mrb55KLxuSj0rWpclHhnCvvXlkGK8s+0+Ks
hsel9speJMW4sspS8a7bKqgvLgghYJFlJzLp9/KERbR6Jjnx0Jf+I/VCFiCEbBALIGi3AE4Q9zto
BDPIUNvGJyGGSolGo5UmwgxDJEYjaDfwwgvPXdja2vjiaAeaNK8ZM2Dc8Vm1MNWDvXC+yk5SaYi8
nOtTWKw6ilCuX2knKrNrjvZ20o7EFddeSlo+F8IlnO6cKXm0369kRryx/uj555453RAKsIww0WBJ
aC22IGARDbrwA+l8/rZlKNg0voiEQByHAIBWow0AGKwN8Kx5LHnkyEP/7sBtN79fa6l27ZJY2wCk
D2iO4Itg+AGq4pmG8VBEGZUq2JmQb0qQf0wa+wjAeIj4GEtVGPDhuYrreQx2WcU8aj+jUjmryOPP
0kJUT7h8MpRcm8oTeEKWpPGVd5jKOT+eJgOWXYdKa1EZGUaIW4oHy4X5fOxMvQxpZP2kczqvOq67
kMp1vQ+g5RNY9yFkC8wSHMM++4U/+mdL60/obkAAPLTZA0JggA7gA+S3EYYY36GzAq7MtoEF8DyF
x7/x+Od6vc75peUFbGwCvp9SEemlCS5c8UxOO9W817GN+the/UoZiirqYfzjVyHW5diRKu1WhTYn
7GBV7+CQ2crvUnXueoUGA9oaDAQjhEGzAXQunN0KV9f+WPXnZKGwAwglPIGvf/2rvWMvvvALjRa4
09uEF6S7enhqtKn0LHamafabma6X2BsurfZTr09hp2rr0zhCTFM85L+z2JOmyUtVdp9KuapGTuLS
taFpQ7j74JLhnHagHWYJXe0HJg1tjzyJkBO0Cbh0+Knf6p843fOuAEJtOy+fCwxrbHa2+KGHv/SL
b3j1m/43r0EtRqpNYSHTiVWBTPlEnNi+hap59mmKAVdePJuzjMjaR4l1y+/lUn3GOJs4rf1Cv3Ko
QsKsyYlzRS1WGYkr37fMcuWJZEqsaJXqe4Ll5REbPU1xI2n87wnq5GLJHHq8Gdzl6us7nu8bgiYB
0/Bhoh7E1qXkwqMP/avkzGn2rUDvcpOdZHDFKVSchFjZu4yHvvqFM8+88OTnlpabCJN0uJPM832a
nanKubTSs6EweJXslKv+lMlyJdqfWDEL58rasTwuqWxkLRtkh0bdKfFLw/gmqoiXwvi5vBSNt/l1
WzhX7mPR8Fz8u9gXK+bXwu00haMkAfkK3ACU0QhfeO7pjccfPkqdTZAfXPa8z2HbdigXRDbB3n37
8OILx/Qjjz30z15x96veF2ulhNdAkmTJ5GewM3GJWlV5MVStxLbgXDpG2fJ6YrSN9jBWiTDmE0oY
CeOUPzNvv0y5MP78/Fre1yqKVqc1rGMrh88tUgiMt4/CBt/T7Gr5e47qFNopJMkp38eUZqZ1LSh1
YB03uJDCNV1dSMtIIHwP1gCqM+C1h7/2k/bYkaQlGYOGAtn5JMErTqEgGIOoB5KMw08//vVTZ08c
YTbwGwRtCivwtP2XaPpkLds8Kq9jkvKUEavOWFoW/l2Ru9M8JyopGtx57ea1I03IV+X6mJSdinUm
8kOgQGG4/lmziA/zqsXnbl+ldtGwA6j1zuDiI4/+QbC+yu2mwqqcX61yxRFKKYH19XUsLrZx9sLZ
8PTpUz/Pkq3nAS72tGxnclmlr1eYJQCwrOUrs0SXa0eqtFtNaaNcp9xelZ3JpWWcl+Vzju28LJ9M
93judwfgrcFnOsdf3GwmCfymj61h8M3lgzywePAKvOYIFv0lmNgiiiKQBIeJvvCGB976l6LQ86WU
oMzIa4mQxjSlvwZIN6hmGjqgpm5nBJvdA1DK75f4+eIqr3kkZ+S5DYZ8PjI+v+AcOnRCzX4jSuvl
+RA0AUnhXEIEQwQt0l8jCJpGxzmMsWilc5S+6thqJjCKDs85UFHgWwVn7OfI1W74WzzOXauGSobi
dUa6/xUXSlYn/xsiC+PPfvPODM8xplLn4vtOK0UKXVVmyftQ6/zqgJYO0A2ApfCsPvNrv/wjvaef
Otvb08a5rS3cHTcRy+tMKTEYDKCUQtDwEIYh1tYunTxz5tTDQcMbfrR57EhVMkEl++a6XtXmFRqD
KnbTJWNt63phbGopBk1/tzKLxRVjVykjVXyXad4alWPjKDsNXQAeAd0z557ZOnPuMEUaDUi0Gk2E
c8pPwA4gVBiGkIoQBAGiaICLq+fjbzz56E8JwZpESZ7I6hTjmVx2pnJ8ki2dQ6mN7Wrxxlb0kvxR
rlPW4hXrTLMvVe5bO3bOndduTG6pOOe0ZVVcm2ApKxa1SgULxq/tuIw0Z+lJhp8k9tITh//x1vET
sZcYBMZiKWiiz+5Uyy644nYoysLQiRhSETqddTz66MNfeO+7P3xuaXHfoTwuvyqeqehONG3S20wt
Oe2Dm2yWjbFBlB6kypDRvfl9VZMib9fl+TAxyVDRRknGqGujsn6hD3nMV6WGk0ZazqmLSuk9yrIc
MSYWjPH+lMZ/CpWcBk4tnms+zjlf2dewZ85uXnr48T/Sq2sIJBANYiip0PflVH/RWeGKU6hGowGt
Y2iToNHwYTnBC0ee2Xzu+ad+Q5sBj2eOnYxnSs+PBrdMQYre0MUdNPJVvqgNK2rKytRkqp1oykR2
av8Kz63Le2eR5Y/jLJccjQfpFWW/qrx2VXalCdtR8bhkNyrKKqbm76qxGRvLGipZV1wUzFVmeUat
p4QdoPPU4d/sPfXMlq8jqKZCMhjADmJI3513zwVX3A6lPAETAVrHCIIAJgE63Q376GNf+9lbbr7j
ry3vbbeqkCm1O/HYCl21CoMr8sIV5DJXXrxy/FLRFjU8V4AJbVvV9cLfw2SVxfcoIGFVyukqe9nU
68PkMON9yO912ZHGKFDpGoBhDsKJBY7zcaOxv6fJWJcLbjvSfCAureq1rz7yL/yzF9kPCKGnYWEg
ogRqwZ9bs3zFKZS1Fp7npTFAxsByDN9XePLJx0+eOn38a654plnsUPkxMH7M066j4jqq6wPjKy5X
tD1G0Uptu3zdZrYbua6X+pjfO5MdqVS3GCJfHo9pTrGVLPcM8+NaKyUGx04c2fj6ky8uhzHgARds
D6LpwSMBO298EXbC9SiO4fkKQgBxHEJrjVargXPnz+iLF8//FCrSS2+Xb52muJi4TlMmQOHcrBb+
7QA7nu+0G7muF95zVi3fhB2MJp85bTzKsmVZAVPu0zx2IhfMyfJx7/SZv987eVYvQMAIi/WoD68Z
IBAKHM+PUPSag2/YZo16oiyRKiWEECCiNOUYM5aWlrBnz56lv/cPf+WINs297aUAa5sWu/YI9HsD
tLwmkgFg/MkPXqQECVefz89FudA+ZVIXt+ysmhS6NGlmUhpMYekq28BkW2OT23ItQsW5a9WU9lFo
c3hf8Tk83l5ZNS8sJtuvYO2mgWthci2drrx8LhFlwBbtJYGtjS52eQuQMTAYAI39wJnB6rr3F//i
LRcuXOhurK0DluErBZmRbyHc9MX1fjvC8uUUh4gghAAzI4oidDqdzjNPP/nbjabirS1gYUEgjtM6
JCdZjvJx8YWm2ZmuBNRp8crPq2Mhy+crr095v2kUp/i3q33eBiJU9eFKjumVAqdaXgkIDbSsADPQ
9wDdBriXcPiN537l0qVLvUGvD6tNuqOGkJBSQqj0d1644ghVTKlERMPN2eI4xubmJj/00Gf/ldWD
MIy6aLXTpJk28+cb2lp4tNoX7U0TPD6qJ1utnQiT1Kl8DqhGkFnsWtPYzQmWCpMTv+xrVyk3TaW8
s9mRqihbecwm3gWYmWVzyUg7zRKyB4gIWLQSloDNBmCWAV69kAw+/aV/01nf5DiMoIQYIlA+X2fd
MrYOtm+HcrF8Iu+ggTE5UhGMMYhjjWefefT4yZPPf/Hgode8T8cAhIIQjDAG8qyzwPRV1mVnyusA
M1IYTF53+eK5DJvlNsbsRLbwfrmmrGCQ5qKzcN4/Lj6TavvgsiMBXEvBROnvaXLg9PlRf3leWdWF
dFYSKGE04KFPwMAHWgowJ198Sn/pq6fJWPgiXeSJKOWodMqoW2shHC/gQrkrH7ErxJDNM8bAWgsp
JTzPg5QSGxtn9GOPfuWfL7SV6XQslCL4vo9uvw8h4c4ahNFKPc3OBFTIPjQ5uavsTNPil2a1a+XP
BiafV54UVRO60q4kxpF7Vk+FKjvSVNmqoq+u9i/HTjQvOFk+pCHukAIagCcA6oR28Pwz/ycdfz7x
IBAIBV8qkOUhMhFRSg3mhMuwQ7mkRgEhCICF1qkrh5QyOycA7vFTTz78lQ9uba3G2j/gtxsgkUb0
2pLSoMo+47IzOe1IVH/9cmSm4rlpyDSkqNkm2vm14nsAmNhBZIKC5s6vZZay+FI1diQuBX4VqWDx
OWUPEi62VQOu6eRCKuFqwHFdGCCSQFcCCRiLIYGOvdi5+NTjf+jFG0hkK9u9nMFZRiClFEhl7J91
uB+5+o8rDNZaiIw/FULAWjtWgBDnzp7oH37ysd9rNH0kSZpeLAiCoSdAWVaZZpMaPjMf69IqWlYb
F9nEOjvTdmSmaVTJRQmnvVPR86OcGy+XNcuyWhnpXOxalR2tyr41rf15YF47lItCeQaIPcJGAGhj
sLJlYQ8f/73TTz7RRVODjYUwnKbXYoYkkSIUpWLJvHDFESrvVI5QQIpkxpg0n5+JEUZ9++xzT/96
uy1sHMdIrEXQ8jCrs+9l8/fbaXsbz7uSfZhFyzfr2Ey0eYXGyPX8nWT5XCA5zVU+UEBiDRr9mM2L
Z39m89SLjOZowucyVF6MMQjDcO7nT+blc+Udcy0jUiJJksKfI1WkUgoNXkGvF+KZp7/6/KkX358s
778lMDaN5rWSYaZsOTlmZ8oF7yLrkx+LEcuY/27HzlRc5avu0VPq5r8G1dQnPxfXPD9VKsgRSwtM
uEYN96/K22RUsqLTqHx5e6V8judhQLpiiS3eo+dcgoUDqZwsoaN9w4zdEaEXA9GCh+7aSX3ya58/
coiaiDUAXw3HSGRzU8cJBIC233C/wJXetHpesDRcHfpMlAxZDEwX4q+2nanOjlQrQ01hj7bDMtWq
7SsoTVWbddevtevPNQADILpaD9t+5tgrAJwilSGiSqbVZWcqtlOVMHLsOqGafZryvDo70vD+ivOz
avHK7ZTbLrc/DZnq+jpRt3Cvi8N4qSNV7tw6jH4mGksMvNMwaYdysHzzds0yAEEgIZikSNmsTOWU
G3evpZ2pVvUNVMtQhTZMmSUt9Z+ZxheM7GDYP4cMNMw7WPUOUxB47F7XB9pxOaf+AVdCzqPsPQue
45zLSvNilsvv9KpTqJzlE0qCpBAQlG7GhpImziHL2Cn3TAuFmFqv9Lz8nvxcFYIB05G2uBBMPLs4
uaf039UHQj0Fy9sbXp/S77rv81KGEWXKf4mvBCLNChV2qJ0Vq5hNGtMjBQsxElFH/n+4pnamqRlp
Z6SA+ceb6H/2O5G0H+N2oGJbQ4pToGC24BzrikuqsiO58OVas3xzx+fRKAFOMbbpSlEoV7zUVadQ
TADylyMCBMEaO1xRnHYmrqdMxeOynQkYb7tORnNRtKkyE9dcB8Y3eCuwhiOErOlv8fmFManrXxnZ
nFrabz6gq0qhruFbpm9aAdfSzrTdNpwsV8XzXMCO9ncS5vZkuMZQwfJd1eershJipwdMIgKRBwli
Io8JAhap7x/IAKTq7TzleCZcXTtT2Y5UnvS64BoExtieu6mdrFS/RGVzx5dpfci/zzTK5AJXvJEL
7Jz1XXYsyXOm8iKRbe6XWgSFBElJYMGwrAGqzxvhUjoQ1Yd4XHU7VN7p3Nm1uEk04LDzzNq+Qws4
j53pegCXHWqn3IZeSlCiTDxvNqNZ4RrIUJRFjjLbTOKgTK4yNKnFqvIAQOH61bYzlW1e05QeeTtc
d53GJ/126k+zM017Tvnc9QpXgkUjGrWTxzpdLVBctjvt8LOZkDp9ps6yPObcCFyRvHk7aWcqZmaq
ilcCqFbpAapfMDBnvNJEPNRlyHD1329nsXJepM+rs6AcqdhaW6BQ9SPBDpbTxfJddQpFRGlOOras
rbUGSDfZEgDs9rRs18TOxBXPnKK2nmZLq3p25fWK9xsPNqzud12/rn+lwpWiUMOkqzyMIL8K/Vc0
75Zx24RUtcyw1rLFaDlIs8KW7FDAtvPm7bSdKc+LR9n/huruvK7DzjQ23FzR/znjlYrtFtsoNDEX
XAk70U62z9kcUgToEUJlogXBhVZE8+HDNfGUSLO8WrbWmtQVKUMkYHzH8UKdfLCKbknXws4E1/08
vW2Mbpno/6zOtqKMWKV7RJmCXWGWb6dhXgJls1wmhXbs1ZSjrrqWryAssgVXO8dmv9Nca+rgatiZ
rmeYpjx5Kb3DFQZz1VR8ANTV5qmT2MdK0ECyeY6bSsfrYR9iuQVFAMUJjC3ZoYpKCkzamYasD48j
4E7ZmfJ4kzG3Hxqdy1m6qbkbSu9TtlO5WB6zzXilse/LmHtTaBcYUS/Uew6Wyq0UqF8VGgIwCRCp
1Ba1r0lar53mRSHR100IxwC7ZThHvOAVGMNtQxa9y9banpQSxqRh8FQKLsxhu3agnbYzbSe183bt
QK5wkJehHkhwKj4wYK1FGIYha5POratAPa66DCWEgNYaIkmQJMlaEASIbeph4Mt0xswTD7XTdqbL
Se1chWB5vXLfyu9vKyjm9QzXehtXC0ACAAMKjLDb2bTasDMs6QqBmt3/4MqAEB7YaGitOQzDUwsB
eCtMuRYhxMSWl0C9LWkaQuyYnangaDkNgXgKUudPmYWCTWtvfqhvZMepoJMncqkB669bGCgh4BMA
z0fcH6wSm1RZAwu5w8rza0KhbJYUo9PpPH9AAkKk4yyEGKopptqBHNq5/FrexpW2M122faliUai0
M9W9w0uA5bvmFIo1iBQ8CXg+od/vnwIbJkqvAfPvAVUH6mqLUXniy9habGxsPMMMJgJJgSzNmKxV
G7v2Z9pxO1PxOdNU2IxJOW4Yt1RvZ6ptj3eegsxtB9rh9l1JXjTz0GDpEdDf2jzOSQKQzebGNxmF
MsbAUx6stlhfXz8ax7BIiRN0rMEqXUG2awfiafegHoFmbb9oZ5onYtbZPurbu97BRaDcrzDfSwoJ
wABGAzYCOmsbz8dhlO4Ik13bSbjqWj6t9TCndK/XO5UkaapOolFOv522A83T/lz7PW1T01fVXjHH
XVX5locsnbJNLJI45F5364U0rZ0FzbBdzbxw5SkU1S8BFA/QaDXASuDFI0+v7V4R/RMbaEQKkI0g
DecoyjFZvfxXl+KJynJMrtQYo0yF+CRDU9rPDpLsYWO2pQK7VaUEKVKZ4Q4hXHEdGC5hld4euPbx
SuyYEdLFsrmylTomNbmUZNnzR9mNxlcRG1l4DIQLAnuM4gPPXzoVCw9bi0BrI4T25xsfF1x1CqWU
Sjdu1jHCwSDu92xnZMgW1XntpigWprnu1NqhqtqvOFcHLi3dS1Wh8FIHojSxKjPA2oJNYrbWN9by
HOZXQ2Fy1RFKej6stdBJhLC/ZTbXL24ImaV+yhBrbMLWIFMO29mfaaJ9oPaZdXVRUdeplsckdSqe
+1aHcorkaSW/d1Qv/RUqRSgYDSRRuHb2TEhGA5bBV2G6X3U7FJSCtqkPtk5C3ty4dG5514H7mYDE
WnAWblJnTJ0lTdY0KmG4Pm+eM56p9KwJBCJ2ylQ7ScHmjVdyur251GxXyc5VhUwAhkjjCwL3uhuD
jTW7m4CQTZozcYeXrqvvbQ4Gw8CTBOgImxurx/cqIEa6pQ1VIEZZIK/zxcvP5+emeptjdL4yvKP0
3Mp4I1S0P63t0jhMi1t6GeqhzLaVk7IkSFG6IQn99bUTXpKwL4C+tdDIvCh2EHbADlWvlDBMsMyQ
kmBNxJuXLj5NBLYEshCQ2J4nRPmcK73WvHnzhsoKh51pTM0+TcvHVx6Z5o9Xqich87bvpG9OCjjZ
zeKxZgshJAIpcObFEw+1JbGyFsYwlAjmHBw3XJO8fGwZghhx1Mf6pfNPW22YlSShvHpnU4xfuyxP
iFKbVe274pm2IzPVhVOUqSPwUoiodd5xVftQplCW01goYQ2fPn70U0tKADqBNWm24ikRQ1cMrr63
OeUbBVvEcYitra1jWsfGAhAqW92zW6sC5K7E/kzzBOA5ffcq2nupOLZeDzAKX59eivdO1h9iFl86
d+GwJIBNMvTQ2WnYPoVy2JmEw87QhkakNSjw0Wg0cPbk0xdtdGngLxzyLvaABX+YXmJIUfI9ZgEM
d+oeIhiXWb4RUhbddoaTmlO2xSKNrWJKbVO1FK4oH5Wcd7l07Fqgp+WlK0fiTh//bX+x8ee45hS7
LtffIEq7X5SPXUoP4VoVizxnKdYLAJYtYWsZCE6fiw+ePLOmtMZmqwHWEVTTwDjm71Ardplw1SkU
ZzIUGwtrDHQS9cNefxVm9vDnWVmy8vHL8M0PWgMwQNLrbST9fqyTCCwos0/tPI9w1REqYTvMlWbi
BDqMzOal1aPGWsiMXtZp71wBfdPklzHt27R28ntL1GmMCjnsVC/bmephFvvSPGAZkBoIV9dO6K2u
DsMQUBLS94Bkhx35sAN2KNcqYCSBpEo5F51ADwZ29fy5R/ffo7/dC3yyZoQYxQC/aam2JrR/ReNw
rnkrslNZVPBwg+xh+6n9iIhqlR5wxTNVGJTHrs87vnNOOuti2VxaNtfz5/VWd5nBhPu6shZr5y/+
Cboh6ygC2gEEBDjmGaI35nuBa6CUEBCegpQEMgxOYlw6f+ZLRodWyile2aimCrZAHcqUIa9fdQ6l
c7PGNZUReIIS1SDTy1QqhVkVDpcLfgB4OuHwzMXf98KYYRksRWqQNjvvxHAZdiiH86tjVAwBUgh4
IGibAEnCl86fP5zEg0jyUguYpE5AtUE2h/GJTak9KVen5vfm99sSKza0KxUqFBrebt68yrx7V/CD
zR1P5MpLN6+jxLzvN6daXkgAnb7pnDz1jB9rkBAYiNRnV0IgcUdszdX/q26HSgB4QmZ7bgA6jrC+
tnoxiQaX2OiWJTXupYBJ6jELBZpm6ylTkold2KfVLbyDK57pm9vOtMPt83z1rQWSra3+5tlzm3u1
Sd3NwLDMUEJitL/JzsDV3wXeFuImLQPGIux1+0kSPWW1+2VdzqnbgWscrf0tAVd7jLW2iHrdF/pr
m4kwnKZVIMCA4DltBvPDJIWa087kglYUQQYt9AyhtbyMMOwjWj+TvPDkU3/wtrtf+YFOmCK5yHJN
WAtoYwBBEEpMSvclFq0ytKNASRKqpn6UUackb2qo5ChRMMcKeq3tTK54Jmv0xFaZxV9nB9hOqZdd
LpGYspLBNX4u1yMpgERrMDOklCCV7gelbRacuiJhv/DYf7nz6Enu8TrCvU2IrsZe4WEz0O6IXZed
ygFXneWTMo3WlUoijuNUfa4Te/Hs2c8mA2jDnIWA0TDRJUmxLe1WnR3KpXZ3gcsV6XqHnYwJyvPh
7STkqZaHf2eRnJJEej6CvXD+/Ce1TtiCkSQJAvKgtYad29HRDVc/HkrKzA3EwyCKQJRq+k4effZE
tLm+AaSq3cQaaG1gwRCCUmqFks2HJjVodTapcqKXKrW7y8409gy8tJCpDNOojKtOXTzSTtuZmFM2
LncjIssQDCgiKAIanW504egLxxMdwRIQxzF85cHECRKbzPl0N2zbDjWvtVkJgdCYLOGlRbvhw3CM
i6eO9roXTx1urOzaL0CwbFPPYSDb0huwmod2JKBaKZDbWYYe4Pm1Yarm9MbpOR+ubd68nY5n4sLE
59JvNmQzwbR4JHe9+a5ba6GUghCA0amDgAQNk1vKs2dOb5w42ttvItgAMAnDDyRSb9GdX/WuvlKC
U/7XcooYUgooqxFtXTCXTj//B5otQwLSExmrl/bSUuqaP9WLvEKjVpl5taDlK1MgW7q/qv3a+i8B
KlVFYS6XQqV/j36349h6uWApNU0MI3QZkEQgA5jIIHr2ud/VqxcMIwY8CSKCxxIKBNp5nUSVHWo+
O5ML2FgQSWit4XkeFAlom8DjhE89/9Rnlt/yId1aaHlCAoIFErYgpmxTAJ5YZCbsRIKGqu+hGrzC
tgQUkKZ4bs68efMugjsfz8TZbWnn89+8qpMBKSDQjI+sbuDyug+2o9zlZBkCBEmA0RZRr8/dxx/7
L814AOYELBWU8mCjBEpIhMLueID6NVCbG0gpESUGnvJhWcPoEA3JOPHc4aObna2tKIrTwaOUxOtS
gsdcZprwBC9dy9sYy0o0g9p9zBOjVPdKqu2vBbhkoNnamDyelULNTcEEZRsBpOytJAFPAkgMwl4/
vvDkk88vSwLDwoo0KVA0iKFIXJXvcw28zVN1pzEGSqnU6zyJ4Stg9fyZrX6//2SUJJmGj2HBQ03O
lcqr5sr5sNP1rzeYF5muBeSyYp7G21qLOIqe3zx9uteUBGYDA5vK6lEMke5muOP9UmIi0Zpr0s5H
M4XXBFij5aU7bmjygOZucGzhxetm47HP/7f7v/fPvvNsn4VYJOgBYyEgJBYIrcjzGI7FN41p9ux4
LytzQPCIclHJPYgw2vi5uEF0bkcypbx6xb7MJEM57nHl5XOtKbKwv1KVvUm4WEIHzymn1c/ZRsfr
cyFitopSSocdqmEVNhoGLW2wsmkQ7FY45gEHloijX//4z8u1i7YLAK0VBAMASGD2EDqwCPTOW4mu
yf5QNcDnTr/4id7WekRsIZGS7G63iyAYeVm4wLV/UxW7hm1cfxnmh8uWxRNg2ZcYDAYwDYUuA2aQ
wG5smsHZc79zrd/rekMonH3+6VOrp04cbmSGJ6UE+r0BpMQwRVeZ5arLLVE+N41dK2rthuem2LG+
mWGn7Uj5M8rHs7YvjMECgGSQIG4q9BgItMXghaOnuy+8cO5aj5/Ig/2ul9I/fzI+cfiJ/7TcIrYm
ZSG8wMdgAPi+zFTuaTFIZSzOjk2mBZxAikzVml5jMHFmNS8cE4MFT7+eHQ/VHlQomL2U1e/l4gLn
GI6p9nnb7c/Qg9riVjxUI9Po/epLoCRMF2h4PsKAEArggO/z6iOP/cfBi8d21vN1BrjuKJQXdvjE
4cd/3zMY2JhhDLCysoz1zS0EQY0XOQqlqKUr2Y0A1HpK5O0Nr2Py+jcz7LQdafScy9M0cgvorW5g
b3sJmZ0f+zT06tcf+zXeWL3mvvxq+2R8Z2fWAsdYO3nswpljR75h99/yFpYeFhaBJElS+8Oc+zfl
SVyGyFJQUIzdixKrWH774qfbjpZsznAc1/eigiZrzMZ0GX29nA5uJ55phFSz1+8FgI5iLEvgkgZk
bLD17PHDnSNHLijdA/yFeV9wLrjuKJRKetDdDf3IQ1/+D9YklpnRD4Fms4kkc8WqsxMBs/nquSJr
Z3E/+maEq0+htldv1TJarRZkD/A1ILoD/sanP/sT2NzQJONrPXzXH0JxFEKy4ae/8cQfwXIHALqd
ARYWWogit2u9a/+ml+H6hFkRdsNEWFpagOlpeBbgQdR75muP/JFvNVhd5Tz9FXDVEYq4vly8aQlR
bxX89S+v8uGHP0kq4o2VJtYssGgkrMF4sVnJ/pY8Kjkwstx7M3ywTIcBwWkhHj+nRVqMGM8XCFyZ
aFwh6otkOywKPCwepVtgCiGGpUo7x2zBPExRM0GBBOpLUQEyNm45QrCtLVIQpCAISsPp87EdhQzU
Kz3u6zQABtb2KvSoA++pRz+x/8mnukudATqN5lWYwY7vd607UAaODBrSg6eEfurxr/80klB7gpEk
Zjw4cIpaPP+t3Yqz8PeVzkr0UobLZemupsdEIIG1MEFkDXYl1px84smfSISxsQQWkqvg/eqA6w6h
ZMTwhERDgJ946EuP986eOrKY0hgMst7Osp1N8b5pWY3K9xXXwmK9b6aMRVfCl69Yt6xQ2Gk7VkDA
Fg1gOULzxNlTpz73padDitGXFkvRtZ/Oavv+TfMmXqu/3KQAHGsIP8bmmeODo4889DNvvPvOf2eb
DTEILQSlgzZEiILSoDJ98gTiXN/7N80az5S9yWiSXiZCpMdjT3DUG913OQjpzLvnyuuoAX+pgXY8
4HOf/+L/NzlyLEZLw8DiQKLQu8ZE6tqjdAkC1UQURbB6gGWf+bkv/Ml/N+fPrbc9ghbjGr6hVq58
jkZeD8PfooETk14WuZ3qmz2vniueaTvtlNu4Iv1zlEESY0/Th796qfP0Jz7xX5eSAXy2adQCXfvp
fNXtUK7aJFWapcZG2N1u4ORzh1dPPfrIr9y4su9vCr9FsCX7UZGVy8M8sriksdTL+fXrff+mee1M
M36A6bYfd0t128nQnHYq12YBA2VwYL3PF7766C+cO/yNzh2BQBiHsEzoKgl3FpadhWuP0iUYJAaq
1QAkQyQ9NOOB+cbnPvczF44f35IkZtrOZhrLN0tEb36+HG/1zeTLVxfPdLl1rxboto/NJ1/oH/3Y
p/6Fh5gTitAKY7ShsNa4ev2YBtcdQoVxjKDVhFCEfmcDu4IAR77x5OnV02d/W2bLc502b1o2oipk
QqnuNwNL54IrFc80re6OG4bbiteeP/YLJ77y6MVdy230kx68KEEDEl117Vc8eXBpP7bj3Fm0y1QX
CwJPLewwRDWtBGCxPujB+D68Zhs6sZaj+Nk333X3X4h2LfnrvS3YZoCgSTB9A2IB2QY22UIxjTYC
wCjmKfdntaLaH7CMTNPy+uXOt1OdWx3FCDt0wK0qHlGtHahKkyYEjSZtNv6iaFsq2H1UwdY01rXc
z9fp+pSO7jhizi5PcTaB8tsEj/ojGdhixkpbQEWMJOxBLSpEIkI46KIhgKUXj289+qu//sPe4ec7
h2IDIxgXFwm26aG1MQApsa35PFnmQ8rrjkJZw4CQaRJDWJCNIXSI7sUzR489/eivLzYkL7aXQCBo
AyhPggjQcRqcVuUm9K3m4Hq9Qy5HikKKkPycIiCO0qktgwa0BQgeFlqLWG40+dTDD/+H8ML5i0QG
sQQiNjCaIYyEn6d0vIZw/SEUGCwISilIYkij4ScD9M4d109/6dM/1V+LO4EQkATEGumGcwQkiUFD
jiscvhW9xa93KCJT1TlfEHSkUydm5SFOLBQrNI1CfGmwdfwTn/rp6ORJowQjUhZ9AJYFpFXw7VXP
2zoB8obF/dur4RQ0eK7qZAgiUNDQIJ2gISQkG8RRD73eZsfsv3P/rt173uQtNqgf5SxNikReg5Do
9AljzrDDWKhxtoyBwhI5XiaUGVlx4SUX/Wmoqt36ERCO+uNl8t6xrEb5qxWOnds/CZcMVN++G3iI
TDmrCYwQTCkBmyQQSiFhIDGMZU8AF7b4uc8/9G/O//avf4w2N9gTDOMBPWsgZYAWBxAhkPjzhkR9
k7F8QlAW6k4ASbCxaEqJJgHJxpo+/Kk/+NeDU8cuLknAk4Ax6VtIKcC62iZV9iB/Ga4dTEOmXIbj
LAmqRZqH0fckFizQP3r00tN/+PF/7a+v2yZbkARCayGFB488MBskc+YlvxKwbTvUDFaKuS4rSUh0
AisIUngwBpBSIfAUEk548+mvnVx/+lU/u+eOm/9Be3GP7HHG1gkg0gaArI1zQnZtoi9VhMN1varK
vPFO21A1Uun3SoBTqcDz1c/3p8oVIEM5KlOWJEYj/4ZKCbQEkJw/b9Yef/gnBo9//cIeQWBPImEL
a4BASHjMSDgGB9deT3vdUSgFA23SuBbyGoitQJQABh5YeFjundcnHvncz534xkPHRDxA4KVUyti0
uHz1XoZrD2XKBBQmIlOazoAZvg9QPOBjj37168e//NlfW948bzUJWKWghYCERAsSQmvENoRe+BYM
33ABgWG1AUhCSA+JJYSxQaIZliWWEePMs984f+ypx//XeNAZKDEK4RDZ/j/TEq18K8JO7rZxOe1X
KSVE4ZqUHqwBjDHwFRD3u+GRJx//m6eeemxjRUeIYBAxYCEgQfCYgDiG5gS2ee2nszy4dGCbI+gq
DkOVAzQIUiooyyCdQEpAeASQhWILu0iIV7scHd88ubuxa88N9977pq0G02ZnCzcvNxCKVONnjIGS
MlVYGAtihicp+xgjRUOutKDMGGK4gHwF+1UeH2WIR359RY/rGd8vV0qMbEhiaEsSgsBGAyjHHI3s
PqLC9jRhcxJFO1VJsVBYWqig1MiVEcxm6rOBXOlCE36RefEc0wNsYK2BZQsDC80GETSMBNgX2G8M
elIjDCTkZmQ3Pv65n3/xV//rL+HIYXNofxN9qyCsheT0w8SwsEpCCQ8ydC+bbm/4eWxYfBkI5Z4y
c9V2zcnExpBWgVnqxJePiD3L39s+eMMer7mATs9CqHR2eJ6EUmlvtE4nCalU2B1OkIK2b7hTfOF8
tZZu/OOg2N4so1NAqKo2aCJwj2rvrzt2jW+1QZYnro/d5yjSKSOOFgslFTzfg6cUBKXSVcICnTjC
ilIIn3nu2KP/9Td+NDnyQufgchNrWxuAN18Q4U5T7GtPI7cJNlFoKh+B7uDUE19YfeazH/ufefXc
YNcisBkTTJKSoPzF8syyLAiWJ91giimqZsyjedXgcnbHuNbg1vSPKDOQeUgQAMtIohgXLWFpYQHi
7JnusT/43R+99JXPX2qGW/CCJgbi2htuXbB9O5QTdjZeSlIDvmD4MkHYW+fNfufM8r6D7ZVDr36b
Dog40WC20JZhONvxTtBwF8QyMiEz/qarZop4tURdVLG0s9uOXBQKWW5ByuxR478jX+7L9ckTY2rE
ETs3Qtr5KJRwfUAClEy3mbHWwiYG1liwNmBj0JUebmvCHP/ox/7+k7/6y79zY9ixy1Li4lYXzb0H
wPF8iVheplAlUMJDnCRQirCrJWHOvBg/+6lP/ouzj3z14b0EbgZeutu3sUiSJN3xTglAEAzbITXK
If17dGLeRJTzwrz7N+005LLktOLKGWKMAUmCUgJkGUZrQBt4EAiEwl5r+dxD3/jMcx//g5/lEyf0
3kBBAnNyuAAAE3tJREFUeUCYxJAvBQp1cPmAU1DbXnELfrUF9dcVC/R1H6JBaDUbiLf6WL+4GUrP
e2T/vr0/RHv3N5QkEEkwE6wkQKZCtDYWIltDOFc+5BQmA3a4EqQrcfnf7M4NLgolOI3YEhk1yn/T
40I/ao5rS/EtSBSOhyNQaGsSoV0rsAeCqCmhiaGkAoFgtYGwjMDzoWS6CDaOP3P+y7/0ix9a+9JX
1g8pBa0T9AH47SWEnRBCzMeX7/Ti9JJTShAzEsUIKd24rWV8mG7ISdRbZd0Z4K4Hvl1ITyifYCGQ
sMm0epQiiylQqGyGcWERsJlv4LRSJdRfSaWEQPVELj/jWiklpEOJ61JKaDYQRLDGwmoNT0j4noeo
P8D6pbVo47d/+U8d+9Snn26ubWB5aRFrSYIOMdp+G7bTB/z5EOJlhCp3mBnUDrBlE9iYsSdYQBOE
bn/DdroXn+LXvfc1nu/dHTQbZAFEOoG2FkJKCEVgPZrQQ9V3wX/Nitn7d7kIVZ3fO/27+Pi69qcF
9+00QrlSpSnUI5whm0YKJDpFKKkgGdhYWzdnT53+f5/42X/+28uDxDY1IbaAXmpjwAzd7WO/38RA
zOdetOMIdePigW3FM7mT49eDqGCYxpgnsrVMOEuAtEWLJXxIhFYjluku4GKrH8eHD/9xe5//Jvuq
Q7es+YpEH9gvA3CD8KK9hGVujpw8CzazVPMEwFoI5mGR2STKN0Y2DmWEzXP1icwpV2IY8ENykh2e
+CA114BUqTBiq8fZOSFG8UZTKWyhQtXXk0WWHZML3GS02XgxVo9tuKDZpMVqaDY4r7awbD0cQBPd
GDgvIzTbVtNXvvRTz/6Tf/aTam0tMdZCqzR2jHSCBjM8JRBKO7dIMgvCzVO/gkK5tTTzgCvngDvr
jkPGudDvd3T0maTdes/yjTfe0Gi2qNsZIBmE2Osvpptl5zxfboOikWLC8jQKkv4WfQKrVnguUY7t
LohOO05JK0eTM76+fZfM5/KGd80PbQp2iFFAqiQBQYSFCFhUbZzf7EAHAvtXmub4Jz7xi4/9p1/6
u/vPrkWRHWxvwK4z+KZDqOaldfQ3NjpW86eX9+3/UPPA/t1aKaIIWEoUQq8YiJP+2GI21Er5ZXRs
M20GZdiYKyUybXfJ8Dv+Owu4JqyoQOgxGWqGUv99HM+3XMug5P2blmH2INq4sL4FsdLEvuWGvfiF
L/7+C7/2m3+FHn6sv7C5jrBx7WOa5oEKO9R88UwucG1JmW4ZWROC76JQQQzfgLHR3Yi3up8U7dZ3
Ld1847JsN2ijO4BqqJEtKmfNihgxJkvkdpqRvcbmS275WsGMQ5yxtll49/AX2U72deMzEZs+XvIJ
P93Top5ldzQP6bqeaSGnFd9T2fBk/cz6yMxga5HAQygtFgPYwWOP/ckz//lXfsg+/Ehnr2fQtx0Y
dR1kWpkD5MFtItS8FMqJUI49fF0IdWnFIABDXdzi/otn1+Nw8Elv98pHcMPu5cFKg7yYR/xwLktQ
8fmTzxnPDT5JocYoVUETWEVBXLYsJ4WopFA0e32Hlo64ngKRI35DAWBjU3YPgBQCSsisbeCcjHDj
3rY9+yef+8LX/91//P7G44c32v0tXNIb6N/QhgpfcqbR8fen7TLhO6skyWwjl9+BkCW61mBZMBq9
dRt97WtPn/TpI3s98/ED73r7LZ1NQ8Nk+rKQsaWUoyPl/mjiWBTuz/PiFfPj5Sr40T2FXyD1eKh7
O1fm2AKV5kze44LcJ1yWIkf7LoR0xWvFcQxrbeqrpxSklEM3I2st9i0Ke+bLn//0yd/5vR/hrz+6
ZrtboOUW0FzERhjhBrzEWb5vNhlquR/AMCNpE/ymguz0OLp46RIlyccV2XfrlZv2M2d0ggqLb87z
l57jCvUu3zdSSlTbkNi1y/uMqZCn9cvp7T2jDDQNFNjRvh1azQURpBCwxiKOYkRhZPmxr3708K/8
xo/Sw4+u7eYIa3oDvaaHldYuqHMxyH9pU6hvOoS69aKHMBBYWzQIKULQjxBsxRxe6qydPnL0d1be
+x1vY+ZDlOuFgeE+vZz5/RWfMzFxLZe8I2js1+WNfqUQalofnes7z85SVoF09E/J0QsKIcDMSJIE
/X7f9nq9//bYP/2nf2HhyKktceIE+noT5ubdWI1D2JM9PODdjPN+z/UG1zXQ6w/dd2UbdIZIu1jK
OV2+6/MK0L5Xvn7phh/8nn9j3v/+P3vaW1HUAW7zBFoMrG+cRae9CK/VgGgoJNYgCSMoTdjlN7Ec
ACfDaLZuTKVwovYeF0I1XXkTZP34CTiy6XP9+y1phVgYaAWwR2DB6ZBHGpxYcNDHLrkXputhNdJQ
exX2UJxc/P2P/ssnfv3XfwLPHn5p68UdkCW6vHLgVMs6EWpOPaKj/kYYRRdOnPlDr6cv3nbjoff6
uxe8F9bO41K/g317D2DBDxD3Igw2OuDYYCFoodXwEWqD85tdKL+eBkzfLmaoqqi5Bgg2tVo6Z3JU
lyuDQysi2dSydFqmad7AjGQQwXQjyMhiUTWxe6ENLT0cv7SKDQ5xcKXNC6fPdp//L7/1Z57+/Y/+
XLR2MfZ63fm+73UO33IItTUI4Z29pL3jp78uuhtfEfua72/eeWPbW1yhXjeBTADJhEB4aJAEW4Zm
iwgGxgNUVZjqmAwyyQ6On8uyuuZqbCqeA9iaMRtOubgQilAvI6UyzvRCDi1rrBhaa1Bi0SYPy/4C
GiqA0Rad7gD9PiPYt4TWouDwmcdOnPuvv/2dF3/vY58dHDtqjBnAv96Czq4wyBsW913ZFq85y1ff
AV8K7FEC+tJ5e+qFJ4/Fg+7/OHTolne2V/buX+9EFIoY5Et4gQ8iiSROkJgYQhGClg8k9Su4FGJ4
XOUxTrA1CMWAg0IJidpUzm61eX37KWLx1BIlAygWCKQHjwIwEXpWY8uE2ESIhUhhryATPfXYHz7x
G7/0Xaf+8OPPt3qbvOxLRIMQQr60lQ4ukDcsXVmEut4pVIME+iJC30sgTQhz/Mza6hNHfzPqRwd2
3bTvVXavpyxrxEbDMKA8BU9KQMfQvQ5I1cfkuP29XHYcO8xDXlVcAyzYrcWr9VeztjaeSUYRGiKA
EB76SYzV3ga2dBdoM9p7mrxwdLVz/H/8j7/z7C/+0t/tf/3hDSl6SAKLONFoxBbGu/bbdu4kyIPL
+69sPBTmdFDMraOXWxwIZS1hUyQwTYVlvwVvtY/esVNhd/PiH5po/bnFXQvvbjE3Wo0myUYDBoDR
GkJrNImghaw3fAJA5k1Q/B0ewxTYKx77BVt3Ztd631RIh1pbUL0nhTX1LOdur4k4SdCNIljfw8pK
G8uBANbOmq0jzz1+4jf/fx9Z/cxn/4AOP50sw8C0FFb1ADq22KWaiL+5CdS3ngwVCYIvA/jWB0cM
ESg0Fn1gsG62nn706cbF8He9tc5NLb9xqw0C1YelyGh4SmKhGSA2DjtMGYm4fC4ZIRTz2O8IuWqK
Y4RdzrXC6tr22dRTuAYJ9LTGgA18T2HBxFYeObK2+slP/9Mzv/f7f+30pz52qpl0eWmxCSsEoq6G
n0i0VAPk+zDf7DLUtxxCKYVGn7E8kBB+E2tNizXaQhBt4lC/x93Hz17aOn3h99bD8JNhs3WXt2/v
webKsrTWUL/TBSlvzhGqV3s7h8fhSSIdLB9Y11Iglwzc3dyCarcQLC9yZ2O9e/QLX/rV53/3Y3+m
80ef/UP/G8+Fext9XEo6OGVCWPZwwC5iV+yDGdj0LNS293R+acGEHeqa25GcPd7Z/NVLpon+oAst
GIu33dTY/9a3va394Nv/j/jue9/a3bWrQTFIWUZgANIWiTAIAyBue9ANhX0X/SzXHwFSwYo0E2pi
DYyxWFTpAGvWsNCwZNMxE+nYtnTLMf71/U9ZqpQySmII4tRRl9Ik/dYWnFWzHHzFTEQGHZD0QEJC
awsODVRCaMNHS/k41wzZX7vQt8889ZnNL3/+71386tee6R0/pWXCaAUL6Kl5v8/O8oQ7nvjzZYQa
Bx0T2oEPTzA6UYx1qUjecXdw09vf/fZD9z/wD/W9d73ZerLBgU+GCEgYCA38kKEMY2uvACxDWIZn
JQIIKBJQLKFA6EgLEgwh0qSULBg0tB1Z2LheaHcNP9s0CE9mPn8MA1iTZhhigyZS3zoWnCWuYRjW
Q2+RpTBAqBOEZCGbHhqtJoQQiPoDDnu9fuO557984tFH/tGRL376YX38hXg3WexqtJAYoDcIodS8
CPEyQpVueGkjVAcKbUloGgvbD9ELE+jWMpo33EytfQfa3hsfeKe6cf9fDl5x24PerYd2q8Xd0o8U
/C0Nv8cI9/XAzNAmtV8xBIhEuupLAdONhtHBaRbYVH6y1oIsQyzUJ3Ikh+HW6xkICZCUkIoAkSKK
tQYGjEtKQzHBZ0aTgaYFWobgMaAscMHfDVgNgoHHhinqm63zZ9bOHDn68dWzZ/7T0ue++tjmxdNh
99yLLHQXi+0G/MU2EiHRNRbNOJnzC7zEEep1N71q/IQDoXLP4ekt7vCWIjuMsAPlA2GIhjZY8T0s
thahIbHaHeDSVhd7FvaRd9MBz7/v7lu91977Peruu37cP3jzXf7iHs9rtOn81kl4UkJJP00PDJVl
4ZaQQiCKBpCURbISQYIgiIYuR4lwha/Uj28joTT/YEaBLKVbkFpmgCxkYxfYJDBJDDZJGuoPm8ZR
sUFv1174cWy9tY0wOXb8qc43Dv9c58mn/yA8fuKiWdvQ66eP8sryAlaWGpCC0Yl76CQa2g9AQQCv
P69n0csIVWrxpY1Q2qSZfTxhITh9lpUEIyVYKjS2tgBSsH4LvLJH2ltuWfHuu+fd3n2v+J/8Qwff
1L/x4Erg+aKt2tRgBQoZGKSyCGuLZDcAy0PZRQoBJX14Mt0G1UT1zqEuCqWUyiiSTikkW/BwzCxu
uLSIRFgYD0iahKjJGCjLfQ45tFovP/3ChXh19dOdF47+6tY3Dj8cP/98t7m6ZncZg2WpcLohYFmD
rE3ZSRZgIcBQKTXGvBuevcQR6mWWbxxkbCCUglCEyGoMdIiEGDLw4TcCdOQGmgNGu0MIIgV4LZg9
eyi5cY9ndi/uu+dV732nv7T0Qbl/92t4/65bwpXF5cFiW4XtgGzg0771HpgJiTHQGWIZTq1ARIRF
R/iCaz1LOPXGSKlfut+WJAEhAUUCPfIgtWUZRaz6A42tTje6ePHF7tmzX+hubn6UHv/yo5uXVjc2
zp3RcbfDPmk0fQKRhWUNBMuI4xhRHIOY4CuFAF6aXkwDiZo7pntHv+/LCDXR/s4ilKcTGBJgJQCV
yj3WaiRRjERH2GhptOFjGT4WjALFDK0tYmugGdgdtkjtXiZxywEPdxxasXcdeq2465b3+3fc/E5/
7647WxdomaRQJD1iqchIAQ2CZsCAEThcc4R0mAUG///2rqbHjSKIvurqnvF4HcebSCEIjsAVkSN3
DvnNkZILEvdcQEREKCFIQLxee70znunuqhy6/bGLhAmWNyzMu4zHmoM14zfVXR/vtbBkwEQoYGAk
Qn0H9UE0hiAf8bydzr73r379Lr5881RfvnoeXrye1T+/9t3bmeokaOw8RAS2cnAnFVaOMOtqzJsl
HnYOdlCBqxJiGMF7qO9QCqEwhNXBT6An1LULbjehYqjBtoCxDj4qtBM4JQytReUsYgt0DFw6QQuB
V48yCEbKGCrjzckySSNFQmgJpEzDYozJ3fs8Ht0d/vL4my8GVfX16HTy1fDevc8HdyYfczUYibUD
ITiunMVWggI7x3Ry9f92fd5YXaeRVSMFibFp2nY+P7+Yzn66mE6/XdXN09NnT35YzGfL6dnvcVWf
qyHRQUkonQFbQheA0jg4YSAoYhfhhYCigCkdHjQdag24VMGKFWII1iSjPKMK2TfwtRe3nFCPPnm/
eah9a/jDf9GH9kk97gvBowAxE1clFXeGVIyG7E4qa6qyZGfH9WdfPmTmT11ZPHBlcUrOjsnyEIYq
AEYMRRJtJcYaPi4R4oX6OIfITKO8LV/8+FvXNot2sWia+XnXLuchrmoh7xUxKMf/dmH1UEIeSrie
UH/CcQllpUgOH0yp6MtJf11y9+vkzBJZTnoMzmYHtSQkE6EISAVaFYGJCoqiFGTT5vTHGKoSgeCB
0MKKwlKEoxRJ6oPT2v92fFhC3W5FjFsICqu0iOuS/Fg2MYVBmv2TVVAiQpedDZWgcWdEfy20SUjD
ubtSZaQAtRVMVnc1EBiKYIOcQleA+kd+TFh9z96qffM2Pf4agVNaeVODMgZMZvNmPBtvxyuEkFPg
uulfJZsoaPLwImf9PyDJOJ82BYCkOhQ0QAQIEuAlW/u4nlDHRH93bxhS5VsumhVrYyJETBGoWlxv
viUQeKPAqrsiKLq+Ynu+NJeboi5MCoECi/XW6UCt/R57YI+d9ehxFUG2ET6NfmW1JJO+KVACyAZm
6xkyTZEIAHze410xidv53GIJUoJRA8rLxuQbnInaE+qo6CPUDYNXOw4S2RrTpMY+AMA5hytOgMm4
gzZLxFa2nQjr9MmuJuDQ5F5AybNNAHjH4UCPXdb4n6Mn1A1jTCViFlIRr0gNPCH12gEYubT/WUsm
s6RIZXLvn8vtUDlhkY/bSegYsruIEIwoSM0OIRmX7u/JoPX4Z3gHu1u4KpDLa14AAAAldEVYdGRh
dGU6Y3JlYXRlADIwMjQtMDMtMzBUMTE6MTY6MzUrMDA6MDDwT5fvAAAAJXRFWHRkYXRlOm1vZGlm
eQAyMDI0LTAzLTMwVDExOjE2OjM1KzAwOjAwgRIvUwAAACh0RVh0ZGF0ZTp0aW1lc3RhbXAAMjAy
NC0wMy0zMFQxMToxNjozNSswMDowMNYHDowAAAAASUVORK5CYII=" />
</svg>
`;
function aprilFoolsEgg(node) {
  let today = /* @__PURE__ */ new Date();
  if (today.getDate() === 1) {
    console.log("超时空猫猫!!!");
    node.querySelector(".name").innerHTML = "ChronoCat";
  }
}
function initSideBar() {
  document.querySelectorAll(".nav-item.liteloader").forEach((node) => {
    if (node.textContent.startsWith("LLOneBot")) {
      aprilFoolsEgg(node);
      let iconEle = node.querySelector(".q-icon");
      iconEle.innerHTML = iconSvg;
    }
  });
}
async function onSettingWindowCreated(view) {
  window.llonebot.log("setting window created");
  initSideBar();
  const isEmpty = (value) => value === void 0 || value === null || value === "";
  let config = await window.llonebot.getConfig();
  let ob11Config = { ...config.ob11 };
  const setConfig = (key, value) => {
    const configKey = key.split(".");
    if (key.indexOf("ob11") === 0) {
      if (configKey.length === 2) ob11Config[configKey[1]] = value;
      else ob11Config[key] = value;
    } else {
      if (configKey.length === 2) config[configKey[0]][configKey[1]] = value;
      else config[key] = value;
      if (!["heartInterval", "token", "ffmpeg"].includes(key)) {
        window.llonebot.setConfig(false, config);
      }
    }
  };
  const parser = new DOMParser();
  const doc = parser.parseFromString(
    [
      "<div>",
      `<style>${StyleRaw}</style>`,
      `<setting-section id="llonebot-error">
            <setting-panel><pre><code></code></pre></setting-panel>
        </setting-section>`,
      SettingList([
        SettingItem(
          '<span id="llonebot-update-title">正在检查 LLOneBot 更新</span>',
          null,
          SettingButton("请稍候", "llonebot-update-button", "secondary")
        )
      ]),
      SettingList(
        [
          SettingItem(
            "是否启用 LLOneBot, 重启QQ后生效",
            null,
            SettingSwitch("enableLLOB", config.enableLLOB, { "control-display-id": "config-enableLLOB" })
          )
        ]
      ),
      SettingList([
        SettingItem(
          "启用 HTTP 服务",
          null,
          SettingSwitch("ob11.enableHttp", config.ob11.enableHttp, { "control-display-id": "config-ob11-httpPort" })
        ),
        SettingItem(
          "HTTP 服务监听端口",
          null,
          `<div class="q-input"><input class="q-input__inner" data-config-key="ob11.httpPort" type="number" min="1" max="65534" value="${config.ob11.httpPort}" placeholder="${config.ob11.httpPort}" /></div>`,
          "config-ob11-httpPort",
          config.ob11.enableHttp
        ),
        SettingItem(
          "启用 HTTP 心跳",
          null,
          SettingSwitch("ob11.enableHttpHeart", config.ob11.enableHttpHeart, {
            "control-display-id": "config-ob11-enableHttpHeart"
          })
        ),
        SettingItem(
          "启用 HTTP 事件上报",
          null,
          SettingSwitch("ob11.enableHttpPost", config.ob11.enableHttpPost, {
            "control-display-id": "config-ob11-httpHosts"
          })
        ),
        `<div class="config-host-list" id="config-ob11-httpHosts" ${config.ob11.enableHttpPost ? "" : "is-hidden"}>
                <setting-item data-direction="row">
                    <div>
                        <setting-text>HTTP 事件上报密钥</setting-text>
                    </div>
                    <div class="q-input">
                        <input id="config-ob11-httpSecret" class="q-input__inner" data-config-key="ob11.httpSecret" type="text" value="${config.ob11.httpSecret}" placeholder="未设置" />
                    </div>
                </setting-item>
                <setting-item data-direction="row">
                    <div>
                        <setting-text>HTTP 事件上报地址</setting-text>
                    </div>
                    <setting-button id="config-ob11-httpHosts-add" data-type="primary">添加</setting-button>
                </setting-item>
                <div id="config-ob11-httpHosts-list"></div>
            </div>`,
        SettingItem(
          "启用正向 WebSocket 服务",
          null,
          SettingSwitch("ob11.enableWs", config.ob11.enableWs, { "control-display-id": "config-ob11-wsPort" })
        ),
        SettingItem(
          "正向 WebSocket 服务监听端口",
          null,
          `<div class="q-input"><input class="q-input__inner" data-config-key="ob11.wsPort" type="number" min="1" max="65534" value="${config.ob11.wsPort}" placeholder="${config.ob11.wsPort}" /></div>`,
          "config-ob11-wsPort",
          config.ob11.enableWs
        ),
        SettingItem(
          "启用反向 WebSocket 服务",
          null,
          SettingSwitch("ob11.enableWsReverse", config.ob11.enableWsReverse, {
            "control-display-id": "config-ob11-wsHosts"
          })
        ),
        `<div class="config-host-list" id="config-ob11-wsHosts" ${config.ob11.enableWsReverse ? "" : "is-hidden"}>
                <setting-item data-direction="row">
                    <div>
                        <setting-text>反向 WebSocket 监听地址</setting-text>
                    </div>
                    <setting-button id="config-ob11-wsHosts-add" data-type="primary">添加</setting-button>
                </setting-item>
                <div id="config-ob11-wsHosts-list"></div>
            </div>`,
        SettingItem(
          " WebSocket 服务心跳间隔",
          "控制每隔多久发送一个心跳包，单位为毫秒",
          `<div class="q-input"><input class="q-input__inner" data-config-key="heartInterval" type="number" min="1000" value="${config.heartInterval}" placeholder="${config.heartInterval}" /></div>`
        ),
        SettingItem(
          "Access token",
          null,
          `<div class="q-input" style="width:210px;"><input class="q-input__inner" data-config-key="token" type="text" value="${config.token}" placeholder="未设置" /></div>`
        ),
        SettingItem(
          "新消息上报格式",
          `如客户端无特殊需求推荐保持默认设置，两者的详细差异可参考 <a href="javascript:LiteLoader.api.openExternal('https://github.com/botuniverse/onebot-11/tree/master/message#readme');">OneBot v11 文档</a>`,
          SettingSelect(
            [
              { text: "消息段", value: "array" },
              { text: "CQ码", value: "string" }
            ],
            "ob11.messagePostFormat",
            config.ob11.messagePostFormat
          )
        ),
        SettingItem(
          "ffmpeg 路径，发送语音、视频需要，同时保证ffprobe和ffmpeg在一起",
          ` <a href="javascript:LiteLoader.api.openExternal('https://llonebot.github.io/zh-CN/guide/ffmpeg');">下载地址</a> <span id="config-ffmpeg-path-text">, 路径:${!isEmpty(config.ffmpeg) ? config.ffmpeg : "未指定"}</span>`,
          SettingButton("选择ffmpeg", "config-ffmpeg-select")
        ),
        SettingItem(
          "音乐卡片签名地址",
          null,
          `<div class="q-input" style="width:210px;"><input class="q-input__inner" data-config-key="musicSignUrl" type="text" value="${config.musicSignUrl}" placeholder="未设置" /></div>`,
          "config-musicSignUrl"
        ),
        SettingItem(
          "快速操作回复自动引用原消息",
          null,
          SettingSwitch("ob11.enableQOAutoQuote", config.ob11.enableQOAutoQuote, { "control-display-id": "config-ob11-enableQOAutoQuote" })
        ),
        SettingItem("", null, SettingButton("保存", "config-ob11-save", "primary"))
      ]),
      SettingList([
        SettingItem(
          "戳一戳消息, 暂时只支持Windows版的LLOneBot",
          `重启QQ后生效，如果导致QQ崩溃请勿开启此项, 群戳一戳只能收到群号`,
          SettingSwitch("enablePoke", config.enablePoke)
        ),
        SettingItem(
          "使用 Base64 编码获取文件",
          "调用 /get_image、/get_record、/get_file 时，没有 url 时添加 Base64 字段",
          SettingSwitch("enableLocalFile2Url", config.enableLocalFile2Url)
        ),
        SettingItem("调试模式", "开启后上报信息会添加 raw 字段以附带原始信息", SettingSwitch("debug", config.debug)),
        SettingItem(
          "上报 Bot 自身发送的消息",
          "上报 event 为 message_sent",
          SettingSwitch("reportSelfMessage", config.reportSelfMessage)
        ),
        SettingItem(
          "自动删除收到的文件",
          "在收到文件后的指定时间内删除该文件",
          SettingSwitch("autoDeleteFile", config.autoDeleteFile, {
            "control-display-id": "config-auto-delete-file-second"
          })
        ),
        SettingItem(
          "自动删除文件时间",
          "单位为秒",
          `<div class="q-input"><input class="q-input__inner" data-config-key="autoDeleteFileSecond" type="number" min="1" value="${config.autoDeleteFileSecond}" placeholder="${config.autoDeleteFileSecond}" /></div>`,
          "config-auto-delete-file-second",
          config.autoDeleteFile
        ),
        SettingItem("写入日志", `将日志文件写入插件的数据文件夹`, SettingSwitch("log", config.log)),
        SettingItem(
          "日志文件目录",
          `${window.LiteLoader.plugins["LLOneBot"].path.data}/logs`,
          SettingButton("打开", "config-open-log-path")
        )
      ]),
      SettingList([
        SettingItem("GitHub 仓库", `https://github.com/LLOneBot/LLOneBot`, SettingButton("点个星星", "open-github")),
        SettingItem("LLOneBot 文档", `https://llonebot.github.io/`, SettingButton("看看文档", "open-docs")),
        SettingItem("Telegram 群", `https://t.me/+nLZEnpne-pQ1OWFl`, SettingButton("进去逛逛", "open-telegram")),
        SettingItem("QQ 群", `545402644`, SettingButton("我要进去", "open-qq-group"))
      ]),
      "</div>"
    ].join(""),
    "text/html"
  );
  const showError = async () => {
    await new Promise((res) => setTimeout(() => res(true), 1e3));
    const errDom = document.querySelector("#llonebot-error") || doc.querySelector("#llonebot-error");
    const errCodeDom = errDom.querySelector("code");
    const errMsg = await window.llonebot.getError();
    if (!errMsg) {
      errDom.classList.remove("show");
    } else {
      errDom.classList.add("show");
    }
    errCodeDom.innerHTML = errMsg;
  };
  showError().then();
  doc.querySelector("#open-github").addEventListener("click", () => {
    window.LiteLoader.api.openExternal("https://github.com/LLOneBot/LLOneBot");
  });
  doc.querySelector("#open-telegram").addEventListener("click", () => {
    window.LiteLoader.api.openExternal("https://t.me/+nLZEnpne-pQ1OWFl");
  });
  doc.querySelector("#open-qq-group").addEventListener("click", () => {
    window.LiteLoader.api.openExternal("https://qm.qq.com/q/bDnHRG38aI");
  });
  doc.querySelector("#open-docs").addEventListener("click", () => {
    window.LiteLoader.api.openExternal("https://llonebot.github.io/");
  });
  const buildHostListItem = (type, host, index, inputAttrs = {}) => {
    const dom = {
      container: document.createElement("setting-item"),
      input: document.createElement("input"),
      inputContainer: document.createElement("div"),
      deleteBtn: document.createElement("setting-button")
    };
    dom.container.classList.add("setting-host-list-item");
    dom.container.dataset.direction = "row";
    Object.assign(dom.input, inputAttrs);
    dom.input.classList.add("q-input__inner");
    dom.input.type = "url";
    dom.input.value = host;
    dom.input.addEventListener("input", () => {
      ob11Config[type][index] = dom.input.value;
    });
    dom.inputContainer.classList.add("q-input");
    dom.inputContainer.appendChild(dom.input);
    dom.deleteBtn.innerHTML = "删除";
    dom.deleteBtn.dataset.type = "secondary";
    dom.deleteBtn.addEventListener("click", () => {
      ob11Config[type].splice(index, 1);
      initReverseHost(type);
    });
    dom.container.appendChild(dom.inputContainer);
    dom.container.appendChild(dom.deleteBtn);
    return dom.container;
  };
  const buildHostList = (hosts, type, inputAttr = {}) => {
    const result = [];
    hosts.forEach((host, index) => {
      result.push(buildHostListItem(type, host, index, inputAttr));
    });
    return result;
  };
  const addReverseHost = (type, doc2 = document, inputAttr = {}) => {
    const hostContainerDom = doc2.body.querySelector(`#config-ob11-${type}-list`);
    hostContainerDom.appendChild(buildHostListItem(type, "", ob11Config[type].length, inputAttr));
    ob11Config[type].push("");
  };
  const initReverseHost = (type, doc2 = document) => {
    const hostContainerDom = doc2.body.querySelector(`#config-ob11-${type}-list`);
    [...hostContainerDom.childNodes].forEach((dom) => dom.remove());
    buildHostList(ob11Config[type], type).forEach((dom) => {
      hostContainerDom.appendChild(dom);
    });
  };
  initReverseHost("httpHosts", doc);
  initReverseHost("wsHosts", doc);
  doc.querySelector("#config-ob11-httpHosts-add").addEventListener(
    "click",
    () => addReverseHost("httpHosts", document, { placeholder: "如：http://127.0.0.1:5140/onebot" })
  );
  doc.querySelector("#config-ob11-wsHosts-add").addEventListener(
    "click",
    () => addReverseHost("wsHosts", document, { placeholder: "如：ws://127.0.0.1:5140/onebot" })
  );
  doc.querySelector("#config-ffmpeg-select").addEventListener("click", () => {
    window.llonebot.selectFile().then((path) => {
      if (!isEmpty(path)) {
        setConfig("ffmpeg", path);
        document.querySelector("#config-ffmpeg-path-text").innerHTML = path;
      }
    });
  });
  doc.querySelector("#config-open-log-path").addEventListener("click", () => {
    window.LiteLoader.api.openPath(window.LiteLoader.plugins["LLOneBot"].path.data);
  });
  doc.querySelectorAll("setting-switch[data-config-key]").forEach((dom) => {
    dom.addEventListener("click", () => {
      const active = dom.getAttribute("is-active") === null;
      setConfig(dom.dataset.configKey, active);
      if (active) dom.setAttribute("is-active", "");
      else dom.removeAttribute("is-active");
      if (!isEmpty(dom.dataset.controlDisplayId)) {
        const displayDom = document.querySelector(`#${dom.dataset.controlDisplayId}`);
        if (active) displayDom.removeAttribute("is-hidden");
        else displayDom.setAttribute("is-hidden", "");
      }
    });
  });
  doc.querySelectorAll("setting-item .q-input input.q-input__inner[data-config-key]").forEach((dom) => {
    dom.addEventListener("input", () => {
      const Type = dom.getAttribute("type");
      const configKey = dom.dataset.configKey;
      const configValue = Type === "number" ? parseInt(dom.value) >= 1 ? parseInt(dom.value) : 1 : dom.value;
      setConfig(configKey, configValue);
    });
  });
  doc.querySelectorAll("ob-setting-select[data-config-key]").forEach((dom) => {
    dom.addEventListener("selected", (e) => {
      const configKey = dom.dataset.configKey;
      const configValue = e.detail.value;
      setConfig(configKey, configValue);
    });
  });
  doc.querySelector("#config-ob11-save").addEventListener("click", () => {
    config.ob11 = ob11Config;
    window.llonebot.setConfig(false, config);
    showError().then();
    alert("保存成功");
  });
  doc.body.childNodes.forEach((node) => {
    view.appendChild(node);
  });
  async function checkVersionFunc(ResultVersion) {
    const titleDom = view.querySelector("#llonebot-update-title");
    const buttonDom = view.querySelector("#llonebot-update-button");
    if (ResultVersion.version === "") {
      titleDom.innerHTML = "检查更新失败";
      buttonDom.innerHTML = "点击重试";
      buttonDom.addEventListener("click", async () => {
        window.llonebot.checkVersion().then(checkVersionFunc);
      });
      return;
    }
    if (!ResultVersion.result) {
      titleDom.innerHTML = "当前已是最新版本 v" + ResultVersion.version;
      buttonDom.innerHTML = "无需更新";
    } else {
      titleDom.innerHTML = "已检测到最新版本 v" + ResultVersion.version;
      buttonDom.innerHTML = "点击更新";
      buttonDom.dataset.type = "primary";
      const update = async () => {
        buttonDom.innerHTML = "正在更新中...";
        const result = await window.llonebot.updateLLOneBot();
        if (result) {
          buttonDom.innerHTML = "更新完成，请重启";
        } else {
          buttonDom.innerHTML = "更新失败，前往仓库下载";
        }
        buttonDom.removeEventListener("click", update);
      };
      buttonDom.addEventListener("click", update);
    }
  }
  window.llonebot.checkVersion().then(checkVersionFunc);
  window.addEventListener("beforeunload", (event) => {
    if (JSON.stringify(ob11Config) === JSON.stringify(config.ob11)) return;
    config.ob11 = ob11Config;
    window.llonebot.setConfig(true, config);
  });
}
function init() {
}
if (location.hash === "#/blank") {
  window.navigation.addEventListener("navigatesuccess", init, { once: true });
}
export {
  onSettingWindowCreated
};
